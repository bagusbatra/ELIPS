// ELIPS LMS - skrip halaman student/dashboard.php
// Diekstrak dari inline <script>; URL relatif terhadap halaman.
document.addEventListener('DOMContentLoaded', function () {
    // Pastikan hanya akun peserta yang dapat membuka halaman ini.
    const sessionUser = ELIPS.getSessionUser();
    if (sessionUser && sessionUser.role !== 'peserta') {
        window.location.href = ELIPS.dashboardPathForRole(sessionUser.role);
        return;
    }

    const student = ELIPS.getCurrentUser();
    if (!student) {
        window.location.href = '../login.php';
        return;
    }

    document.getElementById('studentName').textContent = student.name;
    document.getElementById('studentAvatar').textContent = (student.name || 'S').substring(0, 2).toUpperCase();
    document.getElementById('dashboardGreeting').textContent = 'Selamat datang, ' + student.name + '! Lanjutkan pembelajaranmu.';

    const tbody = document.getElementById('studentCoursesBody');
    const overview = ELIPS.getStudentCourseOverview(student.id);
    const activeOverview = overview.filter(function (item) { return item.enrollment.status === 'active'; });
    const publishedCerts = ELIPS.getPublishedCertificatesByStudent(student.id);
    const awaitingGrade = activeOverview.filter(function (item) { return item.state === 'awaiting-grade'; });

    const stateMap = {
        'locked': { label: 'Belum Dibuka', className: 'badge-warning', icon: 'bi-lock-fill' },
        'certified': { label: 'Sertifikat Terbit', className: 'badge-success', icon: 'bi-patch-check-fill' },
        'completed': { label: 'Selesai', className: 'badge-success', icon: 'bi-check-circle-fill' },
        'awaiting-grade': { label: 'Menunggu Penilaian', className: 'badge-warning', icon: 'bi-hourglass-split' },
        'learning': { label: 'Sedang Belajar', className: 'badge-warning', icon: 'bi-play-circle' },
        'not-started': { label: 'Belum Dimulai', className: 'badge-primary', icon: 'bi-circle' }
    };

    tbody.innerHTML = '';

    if (activeOverview.length === 0) {
        tbody.innerHTML = [
            '<tr><td colspan="5" style="text-align: center; padding: 2.5rem 1rem; color: var(--text-secondary);">',
            '  <i class="bi bi-journal-x" style="display: block; font-size: 2.5rem; opacity: .45; margin-bottom: .75rem;"></i>',
            '  <div style="font-weight: 600; color: var(--text-primary); margin-bottom: .25rem;">Belum ada kursus yang ditugaskan</div>',
            '  <div style="font-size: .875rem; margin-bottom: 1rem;">Hubungi Admin untuk mendapatkan penugasan kursus.</div>',
            '  <a href="../index.php#courses" class="btn btn-outline"><i class="bi bi-compass"></i> Jelajahi Kursus</a>',
            '</td></tr>'
        ].join('');
    }

    activeOverview.forEach(function (item) {
        const course = item.course;
        const progress = item.progress;
        const grade = item.grade;
        const certificate = item.certificate;
        const state = stateMap[item.state] || stateMap['not-started'];
        const modules = ELIPS.getModulesByCourse(course.id).length;
        const canLearn = course.status === 'published';
        const gradeText = grade
            ? ELIPS.escapeHtml(grade.score) + ' (' + ELIPS.escapeHtml(grade.grade) + ')'
            : '-';

        let action = '';
        if (!canLearn) {
            action = '<span class="badge badge-warning"><i class="bi bi-lock-fill"></i> Belum Dibuka</span>';
        } else {
            const learnLabel = item.isComplete ? 'Lihat Materi' : (progress.completed > 0 ? 'Lanjutkan' : 'Mulai');
            const learnIcon = item.isComplete ? 'bi-journal-check' : 'bi-play-fill';
            action = '<div style="display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap;">' +
                '<a href="../learning.php?id=' + course.id + '" class="btn btn-primary" style="padding: 0.5rem 0.875rem; font-size: 0.875rem;"><i class="bi ' + learnIcon + '"></i> ' + learnLabel + '</a>' +
                (certificate && certificate.status === 'publish'
                    ? '<a href="../certificate-view.php?no=' + encodeURIComponent(certificate.certificateNumber) + '" class="btn btn-ghost" style="padding: 0.5rem 0.75rem; font-size: 0.875rem;" title="Lihat Sertifikat"><i class="bi bi-award"></i></a>'
                    : '') +
                '</div>';
        }

        const tr = document.createElement('tr');
        tr.innerHTML = [
            '<td>',
            '  <div class="table-course">',
            '    <div class="table-course-img"></div>',
            '    <div class="table-course-info">',
            '      <div class="table-course-title">' + ELIPS.escapeHtml(course.title) + '</div>',
            '      <div class="table-course-meta">' + ELIPS.escapeHtml(course.category || 'Kursus') + ' &bull; ' + modules + ' Modul &bull; ' + progress.total + ' Pelajaran</div>',
            '    </div>',
            '  </div>',
            '</td>',
            '<td>',
            '  <div class="progress-inline">',
            '    <div class="progress-inline-bar"><div class="progress-inline-fill" style="width: ' + progress.percentage + '%;' + (progress.percentage >= 100 ? ' background: var(--success);' : '') + '"></div></div>',
            '    <span class="progress-inline-text">' + progress.percentage + '%</span>',
            '  </div>',
            '  <small style="color: var(--text-secondary);">' + progress.completed + '/' + progress.total + ' pelajaran</small>',
            '</td>',
            '<td><span>' + gradeText + '</span></td>',
            '<td><span class="badge ' + state.className + '"><i class="bi ' + state.icon + '"></i> ' + state.label + '</span></td>',
            '<td>' + action + '</td>'
        ].join('');
        tbody.appendChild(tr);
    });

    const completedLessons = activeOverview.reduce(function (sum, item) { return sum + item.progress.completed; }, 0);
    const progressSum = activeOverview.reduce(function (sum, item) { return sum + item.progress.percentage; }, 0);

    document.getElementById('statCourses').textContent = activeOverview.length;
    document.getElementById('statLessons').textContent = completedLessons;
    document.getElementById('statProgress').textContent = activeOverview.length > 0 ? Math.round(progressSum / activeOverview.length) + '%' : '0%';
    document.getElementById('statCertificates').textContent = publishedCerts.length;
    renderStudentAttendance();

    const notices = [];
    if (awaitingGrade.length > 0) {
        notices.push(awaitingGrade.length + ' kursus sudah selesai dan menunggu penilaian instruktur.');
    }
    if (notices.length > 0) {
        document.getElementById('studentNoticeText').textContent = notices.join(' ');
        document.getElementById('studentNotice').style.display = 'flex';
    }

    // Segarkan data saat Admin/Instruktur mengubah nilai atau sertifikat
    // dari tab lain, atau saat halaman dipulihkan dari cache browser.
    const refreshKeys = [
        ELIPS.KEYS.certificates, ELIPS.KEYS.grades, ELIPS.KEYS.enrollments,
        ELIPS.KEYS.completedLessons, ELIPS.KEYS.courses
    ];
    window.addEventListener('storage', function (event) {
        if (!event.key || event.key === ELIPS.KEYS.session || refreshKeys.indexOf(event.key) !== -1) {
            window.location.reload();
        }
    });
    window.addEventListener('pageshow', function (event) {
        if (event.persisted) window.location.reload();
    });
});

function renderStudentAttendance() {
    const body = document.getElementById('attendanceRecapBody');
    const result = ELIPS.getMyAttendanceRecap();
    if (!result.ok) {
        body.innerHTML = '<p style="color: var(--text-secondary);">' + ELIPS.escapeHtml(result.message || 'Rekap kehadiran belum tersedia.') + '</p>';
        return;
    }

    const classes = (result.data && result.data.classes) || [];
    if (classes.length === 0) {
        body.innerHTML = [
            '<div style="text-align: center; padding: 1.5rem 1rem; color: var(--text-secondary);">',
            '  <i class="bi bi-calendar-x" style="display: block; font-size: 2rem; opacity: .45; margin-bottom: .5rem;"></i>',
            '  Belum ada kelas dengan jadwal presensi untuk akun Anda.',
            '</div>'
        ].join('');
        document.getElementById('statAttendance').textContent = '0%';
        return;
    }

    const attendanceLabels = {
        present: 'Hadir', late: 'Terlambat', permission: 'Izin',
        sick: 'Sakit', absent: 'Alpa', excused: 'Dispensasi'
    };
    const sessionLabels = {
        scheduled: 'Terjadwal', confirmed: 'Terkonfirmasi', completed: 'Selesai',
        rescheduled: 'Dijadwalkan Ulang', cancelled: 'Dibatalkan', no_show: 'Tidak Hadir'
    };
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

    function formatDate(value) {
        const parts = String(value || '').split('-');
        if (parts.length !== 3) return value || '-';
        return Number(parts[2]) + ' ' + (months[Number(parts[1]) - 1] || parts[1]) + ' ' + parts[0];
    }

    let totalPercentage = 0;
    const html = classes.map(function (recap) {
        const student = recap.students && recap.students[0];
        if (!student) return '';
        const percentage = Number(student.percentage) || 0;
        totalPercentage += percentage;
        const badgeClass = percentage >= 75 ? 'badge-success' : (percentage >= 50 ? 'badge-warning' : 'badge');
        const sessions = student.sessions || [];
        const rows = sessions.length === 0
            ? '<tr><td colspan="5" style="text-align: center; color: var(--text-secondary);">Belum ada sesi pertemuan.</td></tr>'
            : sessions.map(function (detail) {
                const counted = (recap.policy.countedStatuses || []).indexOf(detail.sessionStatus) !== -1;
                const status = detail.status ? (attendanceLabels[detail.status] || detail.status) : 'Belum diisi';
                const statusClass = detail.status === 'present' ? 'badge-success'
                    : (detail.status === 'late' || detail.status === 'permission' || detail.status === 'sick') ? 'badge-warning'
                    : 'badge';
                return '<tr>' +
                    '<td>Pertemuan ' + ELIPS.escapeHtml(detail.sessionNumber) + '</td>' +
                    '<td>' + ELIPS.escapeHtml(formatDate(detail.sessionDate)) + '</td>' +
                    '<td>' + ELIPS.escapeHtml(sessionLabels[detail.sessionStatus] || detail.sessionStatus) + '</td>' +
                    '<td><span class="badge ' + statusClass + '">' + ELIPS.escapeHtml(status) + '</span></td>' +
                    '<td>' + (counted ? (Number(detail.actualJp) || Number(detail.plannedJp) || 0) + ' JP' : '<span style="color: var(--text-secondary);">Tidak dihitung</span>') + '</td>' +
                    '</tr>';
            }).join('');

        return '<div style="border: 1px solid var(--border); border-radius: var(--radius-lg); padding: 1.25rem; margin-bottom: 1rem;">' +
            '<div style="display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem; flex-wrap: wrap; margin-bottom: 0.75rem;">' +
            '  <div>' +
            '    <div style="font-weight: 600;">' + ELIPS.escapeHtml(recap.className) + '</div>' +
            '    <div class="table-course-meta">' + ELIPS.escapeHtml(recap.classCode) + ' • ' + ELIPS.escapeHtml(recap.courseTitle) + '</div>' +
            '  </div>' +
            '  <div style="text-align: right;">' +
            '    <span class="badge ' + badgeClass + '">' + percentage + '% kehadiran</span>' +
            '    <div class="table-course-meta">' + (Number(student.presentJp) || 0) + ' / ' + (Number(student.requiredJp) || 0) + ' JP wajib</div>' +
            '  </div>' +
            '</div>' +
            '<div class="progress-inline" style="margin-bottom: 0.75rem;">' +
            '  <div class="progress-inline-bar"><div class="progress-inline-fill" style="width: ' + Math.min(100, percentage) + '%;' + (percentage >= 75 ? ' background: var(--success);' : '') + '"></div></div>' +
            '  <span class="progress-inline-text">' + percentage + '%</span>' +
            '</div>' +
            '<div class="table-course-meta" style="margin-bottom: 0.75rem;">Hadir ' + (Number(student.present) || 0) +
            ' • Terlambat ' + (Number(student.late) || 0) +
            ' • Izin ' + (Number(student.permission) || 0) +
            ' • Sakit ' + (Number(student.sick) || 0) +
            ' • Alpa ' + (Number(student.absent) || 0) +
            ' • Dispensasi ' + (Number(student.excused) || 0) + '</div>' +
            '<details>' +
            '  <summary style="cursor: pointer; font-size: 0.875rem; color: var(--primary);">Lihat detail per pertemuan</summary>' +
            '  <div style="overflow-x: auto; margin-top: 0.5rem;">' +
            '    <table class="dashboard-table">' +
            '      <thead><tr><th>Pertemuan</th><th>Tanggal</th><th>Status Sesi</th><th>Presensi</th><th>Bobot</th></tr></thead>' +
            '      <tbody>' + rows + '</tbody>' +
            '    </table>' +
            '  </div>' +
            '</details>' +
            '</div>';
    }).join('');

    body.innerHTML = html;
    document.getElementById('statAttendance').textContent = classes.length > 0
        ? Math.round(totalPercentage / classes.length) + '%'
        : '0%';
    const policy = classes[0].policy || {};
    if (policy.presentStatuses) {
        document.getElementById('attendancePolicyBadge').textContent =
            'Hadir = ' + policy.presentStatuses.map(function (status) {
                return attendanceLabels[status] || status;
            }).join(' + ');
    }
}


// ELIPS LMS - skrip halaman instructor/students.php
// Diekstrak dari inline <script>; URL relatif terhadap halaman.
let currentInstructor = null;
let allRows = [];
let currentGradeTarget = null;
let gradeTargets = {};

function myCourses() {
    if (!currentInstructor) return [];
    return ELIPS.getInstructorCourses(currentInstructor.id);
}

document.addEventListener('DOMContentLoaded', function () {
    currentInstructor = ELIPS.requireRole('instruktur');
    if (!currentInstructor) return;

    const name = currentInstructor.name || 'Instruktur';
    document.getElementById('instructorName').textContent = name;
    document.getElementById('instructorAvatar').textContent = name.substring(0, 2).toUpperCase();

    const select = document.getElementById('courseFilter');
    select.innerHTML = '<option value="">Semua Kursus</option>';
    myCourses().forEach(function (course) {
        const option = document.createElement('option');
        option.value = String(course.id);
        option.textContent = course.title;
        select.appendChild(option);
    });

    const params = new URLSearchParams(window.location.search);
    const requestedCourseId = parseInt(params.get('course'), 10);
    if (requestedCourseId && myCourses().some(function (course) { return course.id === requestedCourseId; })) {
        select.value = String(requestedCourseId);
    }

    refreshData();
    populateGradeClassFilter();
    loadGradePanel();
});

function refreshData() {
    if (!currentInstructor) return;
    const courseId = parseInt(document.getElementById('courseFilter').value, 10) || null;
    allRows = ELIPS.getInstructorStudentRows(currentInstructor.id, courseId);
    updateSummary(allRows);
    renderInstructorStudents();
}

function updateSummary(rows) {
    const studentIds = {};
    rows.forEach(function (row) { studentIds[row.enrollment.studentId] = true; });
    document.getElementById('statTotal').textContent = Object.keys(studentIds).length;
    document.getElementById('statLearning').textContent = rows.filter(function (row) { return !row.isComplete; }).length;
    document.getElementById('statComplete').textContent = rows.filter(function (row) { return row.isComplete; }).length;
    document.getElementById('statGraded').textContent = rows.filter(function (row) { return !!row.grade; }).length;
}

function participantState(row) {
    if (row.certificate && row.certificate.status === 'publish') {
        return { label: 'Sertifikat Terbit', className: 'badge-success', icon: 'bi-patch-check-fill' };
    }
    if (row.grade) {
        return { label: 'Sudah Dinilai', className: 'badge-success', icon: 'bi-check-circle-fill' };
    }
    if (row.isComplete) {
        return { label: 'Perlu Dinilai', className: 'badge-warning', icon: 'bi-hourglass-split' };
    }
    if (row.progress.completed > 0) {
        return { label: 'Sedang Belajar', className: 'badge-primary', icon: 'bi-play-circle' };
    }
    return { label: 'Belum Mulai', className: 'badge-primary', icon: 'bi-circle' };
}

function renderInstructorStudents() {
    const tbody = document.getElementById('instructorStudentsBody');
    const statusFilter = document.getElementById('statusFilter').value;
    const search = document.getElementById('studentSearch').value.trim().toLowerCase();
    gradeTargets = {};

    const rows = allRows.filter(function (row) {
        if (statusFilter === 'learning' && row.isComplete) return false;
        if (statusFilter === 'complete' && !row.isComplete) return false;
        if (statusFilter === 'ungraded' && row.grade) return false;
        if (statusFilter === 'graded' && !row.grade) return false;

        if (search) {
            const haystack = (
                (row.student.name || '') + ' ' +
                (row.student.email || '') + ' ' +
                (row.course.title || '')
            ).toLowerCase();
            if (haystack.indexOf(search) === -1) return false;
        }
        return true;
    });

    tbody.innerHTML = '';

    if (rows.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 2rem; color: var(--text-secondary);">Tidak ada peserta yang sesuai filter.</td></tr>';
        return;
    }

    rows.forEach(function (row) {
        const grade = row.grade;
        const certificate = row.certificate;
        const progress = row.progress;
        const state = participantState(row);

        const gradeText = grade
            ? '<span>' + ELIPS.escapeHtml(grade.score) + ' (' + ELIPS.escapeHtml(grade.grade) + ')</span>' +
              (grade.note ? '<div class="table-course-meta">' + ELIPS.escapeHtml(grade.note) + '</div>' : '')
            : '<span style="color: var(--text-secondary);">-</span>';

        let certificateCell = '<span style="color: var(--text-secondary);">-</span>';
        if (certificate) {
            certificateCell = certificate.status === 'publish'
                ? '<span class="badge badge-success"><i class="bi bi-patch-check-fill"></i> Terbit</span>' +
                  '<div style="margin-top: 0.25rem;"><a href="../certificate-view.php?no=' + encodeURIComponent(certificate.certificateNumber) + '" class="table-course-meta" style="color: var(--primary);">Lihat sertifikat</a></div>'
                : '<span class="badge badge-warning"><i class="bi bi-hourglass-split"></i> Draft</span>' +
                  '<div class="table-course-meta">Menunggu Admin</div>';
        }

        gradeTargets[row.enrollment.id] = {
            enrollmentId: row.enrollment.id,
            studentId: row.enrollment.studentId,
            courseId: row.course.id,
            studentName: row.student.name || '',
            courseName: row.course.title || '',
            score: grade ? grade.score : '',
            note: grade ? (grade.note || '') : '',
            progress: progress,
            isComplete: row.isComplete,
            certificateStatus: certificate ? certificate.status : null
        };

        const tr = document.createElement('tr');
        tr.innerHTML = [
            '<td>',
            '  <div class="table-course">',
            '    <div class="dashboard-avatar" style="width: 36px; height: 36px; font-size: 0.875rem;">' + ELIPS.escapeHtml((row.student.name || 'P').substring(0, 2).toUpperCase()) + '</div>',
            '    <div class="table-course-info">',
            '      <div class="table-course-title">' + ELIPS.escapeHtml(row.student.name || '-') + '</div>',
            '      <div class="table-course-meta">' + ELIPS.escapeHtml(row.student.email || '-') + '</div>',
            '    </div>',
            '  </div>',
            '</td>',
            '<td><span>' + ELIPS.escapeHtml(row.course.title) + '</span></td>',
            '<td>',
            '  <div class="progress-inline">',
            '    <div class="progress-inline-bar"><div class="progress-inline-fill" style="width: ' + progress.percentage + '%;' + (progress.percentage >= 100 ? '' : ' background: var(--primary);') + '"></div></div>',
            '    <span class="progress-inline-text">' + progress.percentage + '%</span>',
            '  </div>',
            '  <small style="color: var(--text-secondary);">' + progress.completed + '/' + progress.total + ' pelajaran</small>',
            '</td>',
            '<td><span class="badge ' + state.className + '"><i class="bi ' + state.icon + '"></i> ' + state.label + '</span></td>',
            '<td>' + gradeText + '</td>',
            '<td>' + certificateCell + '</td>',
            '<td>',
            '  <button type="button" class="btn btn-ghost" data-grade-enrollment="' + row.enrollment.id + '" style="padding: 0.375rem 0.625rem; font-size: 0.8125rem;">',
            '    <i class="bi bi-award"></i> ' + (grade ? 'Update Nilai' : 'Beri Nilai'),
            '  </button>',
            '</td>'
        ].join('');
        tbody.appendChild(tr);

        const gradeBtn = tr.querySelector('[data-grade-enrollment]');
        if (gradeBtn) {
            gradeBtn.addEventListener('click', function () {
                openGradeModal(gradeTargets[row.enrollment.id]);
            });
        }
    });
}

let currentGradeClassId = null;
let currentGradePanel = null;
let correctionTarget = null;

function populateGradeClassFilter() {
    const select = document.getElementById('gradeClassFilter');
    if (!select || !currentInstructor) return;
    const classes = ELIPS.getClassesByInstructor(currentInstructor.id);
    select.innerHTML = '';
    if (!classes.length) {
        select.innerHTML = '<option value="">Belum ada kelas</option>';
        return;
    }
    classes.forEach(function (classItem) {
        const option = document.createElement('option');
        option.value = String(classItem.id);
        option.textContent = (classItem.code || 'Kelas') + ' — ' + (classItem.name || '');
        select.appendChild(option);
    });
    const params = new URLSearchParams(window.location.search);
    const requested = parseInt(params.get('class'), 10);
    if (requested && classes.some(function (c) { return Number(c.id) === requested; })) {
        select.value = String(requested);
    }
    currentGradeClassId = Number(select.value) || null;
}

function gradeStatusBadge(status) {
    const map = {
        computed: { label: 'Siap Finalisasi', className: 'badge-warning' },
        incomplete: { label: 'Belum Lengkap', className: 'badge-danger' },
        finalized: { label: 'Final', className: 'badge-success' },
        no_scheme: { label: 'Tanpa Skema', className: 'badge-primary' },
        draft: { label: 'Draft', className: 'badge-primary' }
    };
    const item = map[status] || { label: status || '-', className: 'badge-primary' };
    return '<span class="badge ' + item.className + '">' + ELIPS.escapeHtml(item.label) + '</span>';
}

function componentStatusLabel(component) {
    if (!component) return '-';
    if (component.status === 'excused') return 'Dikecualikan';
    if (component.status === 'missing') return 'Belum ada nilai';
    if (component.score === null || component.score === undefined) return 'Belum dinilai';
    return Number(component.score).toFixed(2).replace(/\.00$/, '');
}

function schemeComponentRow(component, index) {
    const item = component || {};
    function option(value, label, selected) {
        return '<option value="' + value + '"' + (selected === value ? ' selected' : '') + '>' + label + '</option>';
    }
    return [
        '<tr data-component-row>',
        '<input type="hidden" data-field="id" value="' + (item.id ? Number(item.id) : '') + '">',
        '<td><select class="form-input" data-field="type">' +
            option('assignment', 'Tugas', item.type) +
            option('exam', 'Ujian', item.type) +
            option('manual', 'Manual', item.type) +
        '</select></td>',
        '<td><input type="text" class="form-input" data-field="name" value="' + ELIPS.escapeHtml(item.name || '') + '" placeholder="Nama komponen"></td>',
        '<td><input type="number" class="form-input" data-field="weight" min="0" max="100" step="0.01" value="' + (item.weight === undefined ? '' : Number(item.weight)) + '" oninput="updateSchemeWeightTotal()"></td>',
        '<td><select class="form-input" data-field="aggregation">' +
            option('weighted', 'Berbobot', item.aggregation) +
            option('average', 'Rata-rata', item.aggregation) +
        '</select></td>',
        '<td style="text-align:center;"><input type="checkbox" data-field="isRequired"' + (item.isRequired === false ? '' : ' checked') + '></td>',
        '<td><button type="button" class="btn btn-ghost" style="padding: 0.25rem 0.5rem;" onclick="removeSchemeComponentRow(this)" title="Hapus komponen"><i class="bi bi-trash"></i></button></td>',
        '</tr>'
    ].join('');
}

function updateSchemeWeightTotal() {
    const rows = document.querySelectorAll('#schemeComponentsBody [data-component-row]');
    let total = 0;
    rows.forEach(function (row) {
        total += Number(row.querySelector('[data-field="weight"]').value) || 0;
    });
    const target = document.getElementById('schemeWeightTotal');
    if (!target) return;
    target.textContent = 'Total bobot: ' + total.toFixed(2).replace(/\.00$/, '') + '%';
    target.style.color = Math.abs(total - 100) <= 0.01 ? 'var(--success)' : 'var(--danger)';
}

function removeSchemeComponentRow(button) {
    const row = button.closest('[data-component-row]');
    if (row) row.parentNode.removeChild(row);
    updateSchemeWeightTotal();
}

function addSchemeComponentRow() {
    const body = document.getElementById('schemeComponentsBody');
    if (!body) return;
    const wrapper = document.createElement('tbody');
    wrapper.innerHTML = schemeComponentRow({ type: 'manual', aggregation: 'average', weight: 0, isRequired: true }, body.children.length);
    body.appendChild(wrapper.firstElementChild);
    updateSchemeWeightTotal();
}

function renderSchemeCard(scheme) {
    const card = document.getElementById('gradeSchemeCard');
    if (!card) return;
    const components = scheme && Array.isArray(scheme.components) ? scheme.components : [];
    const status = scheme ? scheme.status : 'draft';
    const rows = components.length
        ? components.map(schemeComponentRow).join('')
        : schemeComponentRow({ type: 'assignment', aggregation: 'weighted', weight: 30, isRequired: true }, 0) +
          schemeComponentRow({ type: 'exam', aggregation: 'weighted', weight: 40, isRequired: true }, 1) +
          schemeComponentRow({ type: 'manual', aggregation: 'average', weight: 30, isRequired: true }, 2);
    card.innerHTML = [
        '<div style="border:1px solid var(--border); border-radius:var(--radius-lg); padding:1rem;">',
        '  <div style="display:flex; justify-content:space-between; gap:1rem; flex-wrap:wrap; align-items:center; margin-bottom:0.75rem;">',
        '    <h3 style="font-size:1rem; font-weight:600;">' + (scheme ? 'Skema Kelas' : 'Buat Skema Penilaian') + '</h3>',
        '    <div style="display:flex; gap:0.5rem; flex-wrap:wrap;">',
        '      <button type="button" class="btn btn-outline" onclick="addSchemeComponentRow()"><i class="bi bi-plus-lg"></i> Komponen</button>',
        '      <button type="button" class="btn btn-primary" onclick="submitSchemeForm()"><i class="bi bi-save"></i> Simpan Skema</button>',
        (scheme ? '      <button type="button" class="btn btn-ghost" onclick="removeScheme()"><i class="bi bi-trash"></i> Hapus</button>' : ''),
        '    </div>',
        '  </div>',
        '  <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap:0.75rem;">',
        '    <div class="form-group"><label class="form-label">Nama skema *</label><input type="text" id="schemeName" class="form-input" value="' + ELIPS.escapeHtml(scheme ? scheme.name : 'Skema Penilaian Kelas') + '"></div>',
        '    <div class="form-group"><label class="form-label">Status</label><select id="schemeStatus" class="form-input">' +
            '<option value="draft"' + (status === 'draft' ? ' selected' : '') + (status !== 'draft' ? ' disabled' : '') + '>Draft</option>' +
            '<option value="published"' + (status === 'published' ? ' selected' : '') + '>Published</option>' +
            '<option value="archived"' + (status === 'archived' ? ' selected' : '') + '>Archived</option>' +
          '</select></div>',
        '    <div class="form-group"><label class="form-label">Batas lulus</label><input type="number" id="schemePassScore" class="form-input" min="0" max="100" step="0.01" value="' + (scheme ? Number(scheme.passScore) : 60) + '"></div>',
        '    <div class="form-group"><label class="form-label">Pembulatan</label><select id="schemeRounding" class="form-input">' +
            '<option value="half_up"' + (!scheme || scheme.rounding === 'half_up' ? ' selected' : '') + '>Half up</option>' +
            '<option value="half_down"' + (scheme && scheme.rounding === 'half_down' ? ' selected' : '') + '>Half down</option>' +
            '<option value="floor"' + (scheme && scheme.rounding === 'floor' ? ' selected' : '') + '>Floor</option>' +
            '<option value="ceil"' + (scheme && scheme.rounding === 'ceil' ? ' selected' : '') + '>Ceil</option>' +
          '</select></div>',
        '  </div>',
        '  <div class="form-group"><label class="form-label">Catatan</label><input type="text" id="schemeNotes" class="form-input" value="' + ELIPS.escapeHtml(scheme ? scheme.notes || '' : '') + '"></div>',
        '  <div style="overflow-x:auto;">',
        '    <table class="dashboard-table"><thead><tr><th>Jenis</th><th>Nama</th><th>Bobot (%)</th><th>Agregasi</th><th>Wajib</th><th></th></tr></thead>',
        '    <tbody id="schemeComponentsBody">' + rows + '</tbody></table>',
        '  </div>',
        '  <div id="schemeWeightTotal" style="font-weight:600; margin-top:0.5rem;"></div>',
        '</div>'
    ].join('');
    updateSchemeWeightTotal();
}

function readSchemeForm() {
    const components = [];
    document.querySelectorAll('#schemeComponentsBody [data-component-row]').forEach(function (row) {
        const weight = Number(row.querySelector('[data-field="weight"]').value);
        const name = row.querySelector('[data-field="name"]').value.trim();
        if (!name && !weight) return;
        const idValue = row.querySelector('[data-field="id"]').value;
        components.push({
            id: idValue ? Number(idValue) : null,
            type: row.querySelector('[data-field="type"]').value,
            name: name,
            weight: weight,
            aggregation: row.querySelector('[data-field="aggregation"]').value,
            maxScore: 100,
            isRequired: row.querySelector('[data-field="isRequired"]').checked
        });
    });
    return {
        classId: currentGradeClassId,
        id: currentGradePanel && currentGradePanel.scheme ? currentGradePanel.scheme.id : null,
        name: document.getElementById('schemeName').value.trim(),
        status: document.getElementById('schemeStatus').value,
        passScore: Number(document.getElementById('schemePassScore').value),
        rounding: document.getElementById('schemeRounding').value,
        notes: document.getElementById('schemeNotes').value.trim(),
        components: components,
        actorId: currentInstructor.id
    };
}

function submitSchemeForm() {
    if (!currentGradeClassId) return;
    const result = ELIPS.saveGradeScheme(readSchemeForm());
    ELIPS.toast(result.message);
    if (result.ok) loadGradePanel();
}

function removeScheme() {
    if (!currentGradePanel || !currentGradePanel.scheme) return;
    if (!window.confirm('Hapus skema penilaian kelas ini? Nilai komponen yang tersimpan ikut dihapus.')) return;
    const result = ELIPS.deleteGradeScheme({ id: currentGradePanel.scheme.id, actorId: currentInstructor.id });
    ELIPS.toast(result.message);
    if (result.ok) loadGradePanel();
}

function renderRosterCard(data) {
    const card = document.getElementById('gradeRosterCard');
    if (!card) return;
    if (!data.scheme) {
        card.innerHTML = '<div class="form-hint">Belum ada skema penilaian untuk kelas ini. Buat dan publikasikan skema terlebih dahulu.</div>';
        return;
    }
    const components = data.scheme.components || [];
    const roster = data.roster || [];
    const headerCells = components.map(function (component) {
        return '<th>' + ELIPS.escapeHtml(component.name) + '<div class="table-course-meta">' + Math.round(Number(component.weight)) + '%</div></th>';
    }).join('');
    const rows = roster.map(function (row) {
        const componentCells = components.map(function (component) {
            const computed = (row.components || []).find(function (c) { return Number(c.componentId) === Number(component.id); });
            return '<td>' + renderRosterComponentCell(row, component, computed) + '</td>';
        }).join('');
        let action = '-';
        if (row.gradeStatus === 'finalized') {
            action = '<button type="button" class="btn btn-ghost" style="padding:0.25rem 0.5rem; font-size:0.8125rem;" onclick="openCorrectionModal(' + row.enrollmentId + ')"><i class="bi bi-pencil-square"></i> Koreksi</button>';
        } else if (row.computedStatus === 'computed') {
            action = '<button type="button" class="btn btn-primary" style="padding:0.25rem 0.5rem; font-size:0.8125rem;" onclick="finalizeSingle(' + row.enrollmentId + ')"><i class="bi bi-lock"></i> Finalisasi</button>';
        } else {
            action = '<span class="form-hint">Lengkapi nilai</span>';
        }
        return [
            '<tr>',
            '<td><div class="table-course-title">' + ELIPS.escapeHtml(row.studentName) + '</div><div class="table-course-meta">' + ELIPS.escapeHtml(row.studentEmail || '') + '</div></td>',
            componentCells,
            '<td><strong>' + (row.finalScore === null || row.finalScore === undefined ? '-' : Number(row.finalScore).toFixed(2).replace(/\.00$/, '')) + '</strong><div class="table-course-meta">' + ELIPS.escapeHtml(row.letter || '-') + '</div></td>',
            '<td>' + gradeStatusBadge(row.gradeStatus === 'finalized' ? 'finalized' : row.computedStatus) +
                (row.missing && row.missing.length ? '<div class="table-course-meta" style="color:var(--danger);">Kurang: ' + ELIPS.escapeHtml(row.missing.join(', ')) + '</div>' : '') +
            '</td>',
            '<td>' + action + '</td>',
            '</tr>'
        ].join('');
    }).join('');

    card.innerHTML = [
        '<div style="display:flex; justify-content:space-between; gap:0.75rem; flex-wrap:wrap; align-items:center; margin-bottom:0.75rem;">',
        '  <h3 style="font-size:1rem; font-weight:600;">Nilai Peserta</h3>',
        '  <div style="display:flex; gap:0.5rem; flex-wrap:wrap;">',
        '    <span class="form-hint" style="align-self:center;">Skema: ' + ELIPS.escapeHtml(data.scheme.name) + ' (' + ELIPS.escapeHtml(data.scheme.status) + ')</span>',
        '    <button type="button" class="btn btn-outline" onclick="finalizeAllReady()"><i class="bi bi-lock-fill"></i> Finalisasi yang Lengkap</button>',
        '  </div>',
        '</div>',
        roster.length ? [
            '<div style="overflow-x:auto;"><table class="dashboard-table"><thead><tr>',
            '<th>Peserta</th>', headerCells,
            '<th>Nilai Akhir</th><th>Status</th><th>Aksi</th>',
            '</tr></thead><tbody>', rows, '</tbody></table></div>'
        ].join('') : '<div class="form-hint">Belum ada peserta aktif pada kelas ini.</div>'
    ].join('');
}

function renderRosterComponentCell(row, component, computed) {
    if (!computed) return '-';
    if (computed.status === 'excused') {
        return '<span class="badge badge-primary">Dikecualikan</span>';
    }
    if (component.type === 'manual') {
        if (row.gradeStatus === 'finalized') {
            return computed.score === null || computed.score === undefined
                ? '<span class="form-hint">-</span>'
                : '<span>' + Number(computed.score).toFixed(2).replace(/\.00$/, '') + '</span>';
        }
        const value = computed.score === null || computed.score === undefined ? '' : Number(computed.score);
        return [
            '<div style="display:flex; gap:0.25rem; align-items:center;">',
            '<input type="number" class="form-input" style="width:80px; padding:0.25rem 0.5rem;" min="0" max="100" value="' + value + '" data-manual-component="' + component.id + '" data-manual-enrollment="' + row.enrollmentId + '" onchange="updateManualScore(this)">',
            '<button type="button" class="btn btn-ghost" style="padding:0.2rem 0.4rem;" title="Pengecualian" onclick="exemptComponent(' + row.enrollmentId + ',' + component.id + ')"><i class="bi bi-slash-circle"></i></button>',
            '</div>'
        ].join('');
    }
    if (computed.score === null || computed.score === undefined) {
        return '<span class="badge badge-danger">Belum ada</span>';
    }
    return '<span>' + Number(computed.score).toFixed(2).replace(/\.00$/, '') + '</span>';
}

function loadGradePanel() {
    if (!currentInstructor) return;
    const select = document.getElementById('gradeClassFilter');
    currentGradeClassId = select ? Number(select.value) || null : null;
    const message = document.getElementById('gradePanelMessage');
    if (!currentGradeClassId) {
        if (message) message.textContent = 'Pilih kelas untuk mengatur skema penilaian.';
        document.getElementById('gradeSchemeCard').innerHTML = '';
        document.getElementById('gradeRosterCard').innerHTML = '';
        return;
    }
    const result = ELIPS.gradeRoster({ classId: currentGradeClassId, actorId: currentInstructor.id });
    if (!result.ok) {
        if (message) message.textContent = result.message;
        return;
    }
    currentGradePanel = result.data;
    if (message) message.textContent = '';
    renderSchemeCard(result.data.scheme);
    renderRosterCard(result.data);
}

function updateManualScore(input) {
    if (!currentInstructor) return;
    const value = input.value === '' ? null : Number(input.value);
    const result = ELIPS.saveManualComponentScore({
        enrollmentId: Number(input.getAttribute('data-manual-enrollment')),
        componentId: Number(input.getAttribute('data-manual-component')),
        score: value,
        status: value === null ? 'not_assessed' : 'graded',
        actorId: currentInstructor.id
    });
    ELIPS.toast(result.message);
    if (result.ok) loadGradePanel();
}

function exemptComponent(enrollmentId, componentId) {
    if (!currentInstructor) return;
    const reason = window.prompt('Alasan pengecualian komponen (minimal 5 karakter):', '');
    if (reason === null) return;
    const result = ELIPS.exemptGradeComponent({
        enrollmentId: enrollmentId,
        componentId: componentId,
        reason: reason,
        actorId: currentInstructor.id
    });
    ELIPS.toast(result.message);
    if (result.ok) loadGradePanel();
}

function finalizeSingle(enrollmentId) {
    if (!currentInstructor) return;
    if (!window.confirm('Finalisasi nilai peserta ini? Nilai akan terkunci dan perubahan hanya melalui koreksi.')) return;
    const result = ELIPS.finalizeGrades({ enrollmentIds: [enrollmentId], actorId: currentInstructor.id });
    ELIPS.toast(result.message);
    if (result.ok) loadGradePanel();
}

function finalizeAllReady() {
    if (!currentGradePanel) return;
    const ready = (currentGradePanel.roster || []).filter(function (row) {
        return row.gradeStatus !== 'finalized' && row.computedStatus === 'computed';
    });
    if (!ready.length) {
        ELIPS.toast('Tidak ada peserta yang siap difinalisasi.');
        return;
    }
    if (!window.confirm('Finalisasi ' + ready.length + ' peserta yang nilainya sudah lengkap?')) return;
    const result = ELIPS.finalizeGrades({
        enrollmentIds: ready.map(function (row) { return row.enrollmentId; }),
        actorId: currentInstructor.id
    });
    ELIPS.toast(result.message);
    if (result.ok) loadGradePanel();
}

function openCorrectionModal(enrollmentId) {
    if (!currentGradePanel) return;
    const row = (currentGradePanel.roster || []).find(function (item) { return Number(item.enrollmentId) === Number(enrollmentId); });
    if (!row) return;
    correctionTarget = row;
    document.getElementById('correctionStudentName').textContent = row.studentName;
    document.getElementById('correctionFinalScore').value = '';
    document.getElementById('correctionReason').value = '';
    const container = document.getElementById('correctionComponentInputs');
    const manualComponents = (currentGradePanel.scheme.components || []).filter(function (component) {
        return component.type === 'manual';
    });
    container.innerHTML = manualComponents.length ? manualComponents.map(function (component) {
        const computed = (row.components || []).find(function (c) { return Number(c.componentId) === Number(component.id); });
        const value = computed && computed.score !== null && computed.score !== undefined ? Number(computed.score) : '';
        return '<div class="form-group"><label class="form-label">' + ELIPS.escapeHtml(component.name) + '</label>' +
            '<input type="number" class="form-input" min="0" max="100" value="' + value + '" data-correction-component="' + component.id + '"></div>';
    }).join('') : '<div class="form-hint">Tidak ada komponen manual. Isi nilai akhir pengganti bila perlu.</div>';
    document.getElementById('correctionModal').style.display = 'flex';
}

function closeCorrectionModal() {
    document.getElementById('correctionModal').style.display = 'none';
    correctionTarget = null;
}

function submitCorrection() {
    if (!correctionTarget || !currentInstructor) return;
    const reason = document.getElementById('correctionReason').value.trim();
    if (reason.length < 5) {
        ELIPS.toast('Alasan koreksi wajib diisi minimal 5 karakter.');
        return;
    }
    const componentScores = [];
    document.querySelectorAll('#correctionComponentInputs [data-correction-component]').forEach(function (input) {
        if (input.value !== '') {
            componentScores.push({ componentId: Number(input.getAttribute('data-correction-component')), score: Number(input.value) });
        }
    });
    const finalScoreValue = document.getElementById('correctionFinalScore').value;
    const payload = {
        enrollmentId: correctionTarget.enrollmentId,
        reason: reason,
        actorId: currentInstructor.id
    };
    if (componentScores.length) payload.componentScores = componentScores;
    if (finalScoreValue !== '') payload.finalScore = Number(finalScoreValue);
    if (!componentScores.length && finalScoreValue === '') {
        ELIPS.toast('Masukkan nilai komponen atau nilai akhir pengganti.');
        return;
    }
    const result = ELIPS.correctGrade(payload);
    ELIPS.toast(result.message);
    if (result.ok) {
        closeCorrectionModal();
        loadGradePanel();
    }
}

function resetFilters() {
    document.getElementById('courseFilter').value = '';
    document.getElementById('statusFilter').value = 'all';
    document.getElementById('studentSearch').value = '';
    refreshData();
    populateGradeClassFilter();
    loadGradePanel();
}

function openGradeModal(data) {
    if (!data) return;
    currentGradeTarget = data;
    document.getElementById('gradeStudentName').textContent = data.studentName;
    document.getElementById('gradeCourseName').textContent = data.courseName;
    document.getElementById('gradeProgress').textContent = data.progress.completed + '/' + data.progress.total + ' pelajaran (' + data.progress.percentage + '%)';
    document.getElementById('gradeScore').value = data.score !== '' && data.score !== null ? data.score : '';
    document.getElementById('gradeNote').value = data.note || '';

    const progressNotice = document.getElementById('gradeProgressNotice');
    if (!data.isComplete) {
        progressNotice.innerHTML = '<i class="bi bi-exclamation-triangle"></i> Peserta belum menyelesaikan seluruh materi (' + data.progress.percentage + '%). Nilai tetap dapat disimpan, tetapi sertifikat sebaiknya diberikan setelah materi selesai.';
        progressNotice.style.display = 'block';
        progressNotice.style.background = '#fffbeb';
        progressNotice.style.borderColor = '#fde68a';
        progressNotice.style.color = '#92400e';
    } else {
        progressNotice.innerHTML = '<i class="bi bi-check-circle"></i> Seluruh materi telah diselesaikan peserta.';
        progressNotice.style.display = 'block';
        progressNotice.style.background = '#dcfce7';
        progressNotice.style.borderColor = '#86efac';
        progressNotice.style.color = '#166534';
    }

    const certNote = document.getElementById('gradeCertNote');
    if (data.certificateStatus === 'publish') {
        certNote.innerHTML = '<i class="bi bi-patch-check-fill"></i> Sertifikat sudah <strong>terbit</strong>. Perubahan nilai akan memperbarui data pada sertifikat tersebut.';
    } else if (data.certificateStatus === 'draft') {
        certNote.innerHTML = '<i class="bi bi-hourglass-split"></i> E-sertifikat berstatus <strong>Draft</strong> dan tetap menunggu persetujuan Admin.';
    } else {
        certNote.innerHTML = '<i class="bi bi-info-circle"></i> Setelah disimpan, e-sertifikat otomatis dibuat berstatus <strong>Draft</strong> dan menunggu persetujuan Admin.';
    }

    updateGradeHint();
    document.getElementById('gradeModal').style.display = 'flex';
    document.getElementById('gradeScore').focus();
}

function closeGradeModal() {
    document.getElementById('gradeModal').style.display = 'none';
    document.getElementById('gradeScore').value = '';
    document.getElementById('gradeNote').value = '';
    currentGradeTarget = null;
}

function updateGradeHint() {
    const value = document.getElementById('gradeScore').value;
    const hint = document.getElementById('gradeHint');
    if (value === '') {
        hint.textContent = 'Grade otomatis: A (90+), A- (80+), B+ (75+), B (70+), B- (65+), C+ (60+), C (55+), D (50+), E (<50).';
        return;
    }
    const score = parseInt(value, 10);
    if (isNaN(score)) return;
    hint.textContent = 'Grade otomatis: ' + ELIPS.gradeLetter(score) + ' (' + score + ').';
}

function saveGrade() {
    if (!currentGradeTarget || !currentInstructor) return;

    const score = parseInt(document.getElementById('gradeScore').value, 10);
    if (isNaN(score) || score < 0 || score > 100) {
        ELIPS.toast('Masukkan nilai antara 0-100.');
        return;
    }

    const result = ELIPS.saveGrade({
        studentId: currentGradeTarget.studentId,
        courseId: currentGradeTarget.courseId,
        enrollmentId: currentGradeTarget.enrollmentId,
        score: score,
        note: document.getElementById('gradeNote').value.trim(),
        instructorId: currentInstructor.id
    });

    if (!result.ok) {
        ELIPS.toast(result.message);
        return;
    }

    ELIPS.toast(result.message);
    closeGradeModal();
    refreshData();
}


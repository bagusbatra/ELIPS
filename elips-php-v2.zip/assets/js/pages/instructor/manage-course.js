// ELIPS LMS - skrip halaman instructor/manage-course.php
// Diekstrak dari inline <script>; URL relatif terhadap halaman.
let currentInstructor = null;
let selectedCourseId = null;
let editingModuleId = null;
let editingLessonId = null;
let selectedMaterialClassId = null;
let editingMaterialId = null;
let selectedTaskClassId = null;
let editingAssignmentTaskId = null;
let editingExamTaskId = null;
let openSubmissionsAssignmentId = null;
let submissionsCache = null;
let openExamResultsId = null;
let examResultsCache = null;

const ASSIGNMENT_TYPE_LABELS = {
    file_upload: 'Unggah File',
    text_submission: 'Jawaban Teks',
    in_class_practice: 'Praktik Kelas',
    external_reference: 'Referensi Eksternal'
};
const TASK_STATUS_LABELS = {
    draft: 'Draft',
    published: 'Published',
    closed: 'Closed',
    archived: 'Archived'
};
const SUBMISSION_STATUS_LABELS = {
    submitted: 'Dikumpulkan',
    late: 'Terlambat',
    reviewed: 'Dinilai',
    revision_requested: 'Minta Revisi',
    resubmitted: 'Dikumpulkan Ulang',
    accepted: 'Diterima'
};
const EXAM_TYPE_LABELS = {
    written: 'Tertulis',
    practical: 'Praktik',
    oral: 'Lisan',
    project: 'Proyek',
    other: 'Lainnya'
};
const PARTICIPANT_STATUS_LABELS = {
    registered: 'Terdaftar',
    attended: 'Hadir',
    absent: 'Tidak Hadir',
    excused: 'Izin'
};
const RESULT_STATUS_LABELS = {
    not_assessed: 'Belum Dinilai',
    excused: 'Izin',
    missing: 'Tidak Ada Nilai',
    graded: 'Dinilai'
};

const MATERIAL_TYPE_LABELS = {
    text: 'Teks',
    document: 'Dokumen',
    video: 'Video',
    link: 'Link',
    file: 'File'
};
const MATERIAL_ACCESS_LABELS = {
    required: 'Wajib',
    optional: 'Opsional',
    reference: 'Referensi'
};
const MATERIAL_MODE_LABELS = {
    open: 'Open',
    sequential: 'Sequential',
    scheduled: 'Scheduled',
    conditional: 'Conditional'
};

function myCourses() {
    if (!currentInstructor) return [];
    return ELIPS.getInstructorCourses(currentInstructor.id);
}

document.addEventListener('DOMContentLoaded', function () {
    currentInstructor = ELIPS.requireRole('instruktur');
    if (!currentInstructor) return;

    const name = currentInstructor.name || 'Instruktur';
    document.getElementById('instructorName').textContent = name;
    document.getElementById('instructorAvatar').textContent = name.substring(0, 2).toUpperCase();

    const params = new URLSearchParams(window.location.search);
    const requestedCourseId = parseInt(params.get('course'), 10);
    initInstructor(requestedCourseId);
});

function initInstructor(preferredCourseId) {
    const courses = myCourses();
    document.getElementById('courseCountBadge').textContent = courses.length + ' Kursus';

    const select = document.getElementById('structureCourseSelect');
    select.innerHTML = '';
    if (courses.length === 0) {
        select.innerHTML = '<option value="">Belum ada kursus ditugaskan</option>';
        selectedCourseId = null;
    } else {
        courses.forEach(function (course) {
            const option = document.createElement('option');
            option.value = String(course.id);
            option.textContent = course.title + (course.status === 'published' ? '' : ' (Draft)');
            select.appendChild(option);
        });

        const preferred = [preferredCourseId, selectedCourseId].find(function (id) {
            return id && courses.some(function (course) { return course.id === Number(id); });
        });
        selectedCourseId = preferred ? Number(preferred) : courses[0].id;
        select.value = String(selectedCourseId);
    }

    renderInstructorCourses();
    renderStructure();
    renderClassMaterials();
    renderTasks();
}

function renderInstructorCourses() {
    const tbody = document.getElementById('instructorCoursesBody');
    const courses = myCourses();
    tbody.innerHTML = '';

    if (courses.length === 0) {
        tbody.innerHTML = [
            '<tr><td colspan="5" style="text-align: center; padding: 2.5rem 1rem; color: var(--text-secondary);">',
            '  <i class="bi bi-journal-x" style="display: block; font-size: 2.5rem; opacity: .45; margin-bottom: .75rem;"></i>',
            '  <div style="font-weight: 600; color: var(--text-primary); margin-bottom: .25rem;">Belum ada kursus yang ditugaskan</div>',
            '  <div style="font-size: .875rem;">Admin akan menugaskan Anda sebagai instruktur pada sebuah kursus.</div>',
            '</td></tr>'
        ].join('');
        return;
    }

    courses.forEach(function (course) {
        const modules = ELIPS.getModulesByCourse(course.id).length;
        const lessons = ELIPS.getLessonsByCourse(course.id).length;
        const participants = ELIPS.getEnrollmentsByCourse(course.id).filter(function (enrollment) {
            return enrollment.status === 'active';
        }).length;
        const published = course.status === 'published';
        const isSelected = course.id === selectedCourseId;
        const tr = document.createElement('tr');
        if (isSelected) tr.style.background = 'var(--primary-light)';
        tr.innerHTML = [
            '<td>',
            '  <div class="table-course">',
            '    <div class="table-course-img"></div>',
            '    <div class="table-course-info">',
            '      <div class="table-course-title">' + ELIPS.escapeHtml(course.title) + '</div>',
            '      <div class="table-course-meta">' + ELIPS.escapeHtml(course.category || 'Kursus') + '</div>',
            '    </div>',
            '  </div>',
            '</td>',
            '<td><span>' + modules + ' Modul &bull; ' + lessons + ' Pelajaran</span></td>',
            '<td><span>' + participants + ' Peserta</span></td>',
            '<td><span class="badge ' + (published ? 'badge-success' : 'badge-warning') + '"><i class="bi ' + (published ? 'bi-eye' : 'bi-pencil') + '"></i> ' + (published ? 'Dipublikasi' : 'Draft') + '</span></td>',
            '<td>',
            '  <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">',
            '    <button type="button" class="btn btn-ghost" style="padding: 0.375rem 0.625rem; font-size: 0.8125rem;" onclick="selectCourseForStructure(' + course.id + ', true)"><i class="bi bi-folder2-open"></i> Kelola Struktur</button>',
            '    <a href="students.php?course=' + course.id + '" class="btn btn-ghost" style="padding: 0.375rem 0.625rem; font-size: 0.8125rem;"><i class="bi bi-people"></i></a>',
            '    <a href="../course-detail.php?id=' + course.id + '" class="btn btn-ghost" style="padding: 0.375rem 0.625rem; font-size: 0.8125rem;" title="Pratinjau kursus"><i class="bi bi-eye"></i></a>',
            '  </div>',
            '</td>'
        ].join('');
        tbody.appendChild(tr);
    });
}

function selectCourseForStructure(courseId, scrollToSection) {
    const id = Number(courseId);
    if (!myCourses().some(function (course) { return course.id === id; })) return;
    selectedCourseId = id;
    const select = document.getElementById('structureCourseSelect');
    if (select) select.value = String(id);
    renderInstructorCourses();
    renderStructure();
    renderClassMaterials();
    renderTasks();
    if (scrollToSection) {
        document.getElementById('structureSection').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

function renderStructure() {
    const container = document.getElementById('instructorModules');
    const label = document.getElementById('structureCourseLabel');
    const course = selectedCourseId ? ELIPS.getCourseById(selectedCourseId) : null;

    if (!course || !myCourses().some(function (item) { return item.id === course.id; })) {
        label.textContent = 'Pilih kursus untuk melihat strukturnya';
        container.innerHTML = '<p style="color: var(--text-secondary);">Pilih kursus yang ditugaskan untuk melihat strukturnya.</p>';
        return;
    }

    label.textContent = course.title + ' • ' + (course.status === 'published' ? 'Dipublikasi' : 'Draft');
    const structure = ELIPS.getCourseStructure(course.id);

    if (structure.length === 0) {
        container.innerHTML = [
            '<div style="text-align: center; padding: 2.5rem 1rem; color: var(--text-secondary); border: 1px dashed var(--border); border-radius: var(--radius);">',
            '  <i class="bi bi-folder-plus" style="display: block; font-size: 2.5rem; opacity: .45; margin-bottom: .75rem;"></i>',
            '  <div style="font-weight: 600; color: var(--text-primary); margin-bottom: .25rem;">Belum ada modul</div>',
            '  <div style="font-size: .875rem; margin-bottom: 1rem;">Klik "Tambah Modul" untuk mulai menyusun materi kursus.</div>',
            '  <button class="btn btn-primary" onclick="openModuleModal()"><i class="bi bi-folder-plus"></i> Tambah Modul</button>',
            '</div>'
        ].join('');
        return;
    }

    container.innerHTML = structure.map(function (item) {
        const lessons = item.lessons.map(function (lesson) {
            const icon = lesson.type === 'video' ? 'bi-play-circle' : lesson.type === 'link' ? 'bi-link-45deg' : lesson.type === 'file' ? 'bi-file-earmark' : 'bi-file-text';
            const typeLabel = lesson.type === 'video' ? 'Video' : lesson.type === 'link' ? 'Link' : lesson.type === 'file' ? 'File' : 'Teks';
            return [
                '<div class="lesson-item" style="justify-content: space-between; gap: 0.75rem;">',
                '  <div style="display: flex; align-items: center; gap: 0.5rem; min-width: 0;">',
                '    <i class="bi ' + icon + '"></i>',
                '    <span style="overflow: hidden; text-overflow: ellipsis;">' + ELIPS.escapeHtml(lesson.title) + '</span>',
                '    <span class="badge badge-primary" style="font-size: 0.6875rem; flex-shrink: 0;">' + typeLabel + '</span>',
                '  </div>',
                '  <div style="display: flex; align-items: center; gap: 0.25rem; flex-shrink: 0;">',
                '    <button type="button" class="btn btn-ghost" style="padding: 0.125rem 0.5rem; font-size: 0.75rem;" onclick="openLessonModal(' + item.module.id + ', ' + lesson.id + ')" title="Edit materi"><i class="bi bi-pencil"></i></button>',
                '    <button type="button" class="btn btn-ghost" style="padding: 0.125rem 0.5rem; font-size: 0.75rem; color: var(--danger);" onclick="deleteLesson(' + lesson.id + ')" title="Hapus materi"><i class="bi bi-trash"></i></button>',
                '  </div>',
                '</div>'
            ].join('');
        }).join('') || '<div class="lesson-item" style="color: var(--text-secondary);">Belum ada materi pada modul ini.</div>';

        const description = item.module.description
            ? '<div class="table-course-meta" style="margin-top: 0.125rem;">' + ELIPS.escapeHtml(item.module.description) + '</div>'
            : '';

        return [
            '<div class="module-item">',
            '  <div class="module-header" style="flex-wrap: wrap; gap: 0.5rem;">',
            '    <div class="module-info">',
            '      <i class="bi bi-folder"></i>',
            '      <div>',
            '        <div class="module-title">' + ELIPS.escapeHtml(item.module.title) + '</div>',
            description,
            '      </div>',
            '    </div>',
            '    <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">',
            '      <span class="module-count">' + item.lessons.length + ' Pelajaran</span>',
            '      <button type="button" class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="openLessonModal(' + item.module.id + ')" title="Tambah materi"><i class="bi bi-plus-lg"></i> Materi</button>',
            '      <button type="button" class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="openModuleModal(' + item.module.id + ')" title="Edit modul"><i class="bi bi-pencil"></i></button>',
            '      <button type="button" class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem; color: var(--danger);" onclick="deleteModule(' + item.module.id + ')" title="Hapus modul"><i class="bi bi-trash"></i></button>',
            '    </div>',
            '  </div>',
            '  <div class="module-lessons">' + lessons + '</div>',
            '</div>'
        ].join('');
    }).join('');
}

// ---------- Materi tambahan & akses kelas (Phase 4) ----------
function manageableClassesForCourse(courseId) {
    if (!currentInstructor || !courseId) return [];
    return ELIPS.getClassesByCourse(courseId).filter(function (item) {
        return Number(item.instructorId) === Number(currentInstructor.id);
    }).sort(function (a, b) {
        return Number(b.id) - Number(a.id);
    });
}

function classCurriculumLessons(classItem) {
    if (!classItem) return [];
    const moduleMap = {};
    ELIPS.getModules()
        .filter(function (module) {
            return Number(module.courseId) === Number(classItem.courseId) &&
                Number(module.curriculumVersionId) === Number(classItem.curriculumVersionId);
        })
        .sort(function (a, b) {
            return (Number(a.order) || 0) - (Number(b.order) || 0);
        })
        .forEach(function (module, index) {
            moduleMap[module.id] = { module: module, index: index };
        });
    return ELIPS.getLessons()
        .filter(function (lesson) {
            return Number(lesson.courseId) === Number(classItem.courseId) &&
                Number(lesson.curriculumVersionId) === Number(classItem.curriculumVersionId) &&
                moduleMap[lesson.moduleId] !== undefined;
        })
        .sort(function (a, b) {
            const moduleA = moduleMap[a.moduleId];
            const moduleB = moduleMap[b.moduleId];
            if (moduleA.index !== moduleB.index) return moduleA.index - moduleB.index;
            return (Number(a.order) || 0) - (Number(b.order) || 0);
        });
}

function materialStatusBadge(status) {
    return status === 'hidden'
        ? '<span class="badge badge-warning">Disembunyikan</span>'
        : '<span class="badge badge-success">Aktif</span>';
}

function renderClassMaterials() {
    const select = document.getElementById('classMaterialClassSelect');
    const label = document.getElementById('classMaterialLabel');
    const panel = document.getElementById('classMaterialSettingsPanel');
    const list = document.getElementById('classMaterialList');
    if (!select || !panel || !list) return;

    const course = selectedCourseId ? ELIPS.getCourseById(selectedCourseId) : null;
    if (!course) {
        select.innerHTML = '<option value="">Pilih kursus terlebih dahulu</option>';
        label.textContent = 'Pilih kursus untuk mengelola materi tambahan';
        panel.style.display = 'none';
        list.innerHTML = '<p style="color: var(--text-secondary);">Pilih kursus yang ditugaskan.</p>';
        return;
    }

    const classes = manageableClassesForCourse(course.id);
    if (classes.length === 0) {
        select.innerHTML = '<option value="">Belum ada kelas yang Anda ampu</option>';
        label.textContent = 'Belum ada kelas untuk kursus ini';
        panel.style.display = 'none';
        list.innerHTML = '<p style="color: var(--text-secondary);">Admin belum menugaskan Anda pada kelas untuk kursus ini.</p>';
        return;
    }

    const selectedStillValid = selectedMaterialClassId && classes.some(function (item) {
        return Number(item.id) === Number(selectedMaterialClassId);
    });
    if (!selectedStillValid) selectedMaterialClassId = Number(classes[0].id);

    select.innerHTML = classes.map(function (item) {
        return '<option value="' + item.id + '" ' + (Number(item.id) === Number(selectedMaterialClassId) ? 'selected' : '') + '>' +
            ELIPS.escapeHtml(item.name + ' (' + item.code + ')') + '</option>';
    }).join('');

    const classItem = classes.find(function (item) {
        return Number(item.id) === Number(selectedMaterialClassId);
    });
    label.textContent = classItem.name + ' • ' + classItem.code;
    renderClassMaterialSettings(classItem, panel);
    renderClassMaterialList(classItem, list);
}

function renderClassMaterialSettings(classItem, panel) {
    const result = ELIPS.getMaterialSettings(classItem.id);
    if (!result.ok) {
        panel.style.display = 'block';
        panel.innerHTML = '<span style="color: var(--danger);">' + ELIPS.escapeHtml(result.message) + '</span>';
        return;
    }
    const settings = result.data;
    panel.style.display = 'block';
    panel.innerHTML = [
        '<div style="display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap; margin-bottom: 0.75rem;">',
        '  <strong style="font-size: 0.9375rem;">Pengaturan Akses Materi</strong>',
        '  <span class="badge badge-primary">' + ELIPS.escapeHtml(MATERIAL_MODE_LABELS[settings.accessMode] || settings.accessMode) + '</span>',
        '</div>',
        '<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 0.75rem;">',
        '  <div class="form-group" style="margin: 0;">',
        '    <label class="form-label" for="classAccessMode">Mode Akses</label>',
        '    <select id="classAccessMode" class="form-input">',
        '      <option value="open">Open</option>',
        '      <option value="sequential">Sequential</option>',
        '      <option value="scheduled">Scheduled</option>',
        '      <option value="conditional">Conditional</option>',
        '    </select>',
        '  </div>',
        '  <div class="form-group" style="margin: 0;">',
        '    <label class="form-label" for="classAccessNotes">Catatan</label>',
        '    <input type="text" id="classAccessNotes" class="form-input" placeholder="Opsional">',
        '  </div>',
        '</div>',
        '<label style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.875rem; margin-top: 0.75rem;">',
        '  <input type="checkbox" id="classAccessApproval" style="width: auto;"> Wajib persetujuan instruktur untuk menandai selesai',
        '</label>',
        '<div style="margin-top: 0.75rem;">',
        '  <button class="btn btn-outline" onclick="saveClassMaterialSettings()"><i class="bi bi-save"></i> Simpan Pengaturan</button>',
        '</div>'
    ].join('');
    document.getElementById('classAccessMode').value = settings.accessMode;
    document.getElementById('classAccessNotes').value = settings.notes || '';
    document.getElementById('classAccessApproval').checked = !!settings.requireInstructorApproval;
}

function saveClassMaterialSettings() {
    if (!selectedMaterialClassId) return;
    const result = ELIPS.updateMaterialSettings(selectedMaterialClassId, {
        accessMode: document.getElementById('classAccessMode').value,
        requireInstructorApproval: document.getElementById('classAccessApproval').checked,
        notes: document.getElementById('classAccessNotes').value
    });
    ELIPS.toast(result.message);
    if (result.ok) renderClassMaterials();
}

function renderClassMaterialList(classItem, container) {
    const materials = ELIPS.getClassMaterialsByClass(classItem.id);
    if (materials.length === 0) {
        container.innerHTML = [
            '<div style="text-align: center; padding: 2rem 1rem; color: var(--text-secondary); border: 1px dashed var(--border); border-radius: var(--radius);">',
            '  <i class="bi bi-journal-plus" style="display: block; font-size: 2.25rem; opacity: .45; margin-bottom: .5rem;"></i>',
            '  <div style="font-weight: 600; color: var(--text-primary); margin-bottom: .25rem;">Belum ada materi tambahan</div>',
            '  <div style="font-size: .875rem;">Gunakan tombol "Tambah Materi" untuk menambahkan bahan pendukung kelas.</div>',
            '</div>'
        ].join('');
        return;
    }

    container.innerHTML = '<div style="display: flex; flex-direction: column; gap: 0.75rem;">' + materials.map(function (item) {
        const lesson = item.lessonId ? ELIPS.getLessons().find(function (row) {
            return Number(row.id) === Number(item.lessonId);
        }) : null;
        const session = item.sessionId ? ELIPS.getClassSessionById(item.sessionId) : null;
        const relation = lesson ? 'Pelajaran: ' + lesson.title : (session ? 'Sesi: ' + session.title : 'Tanpa relasi');
        return [
            '<div style="display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem; padding: 0.875rem 1rem; border: 1px solid var(--border); border-radius: var(--radius); flex-wrap: wrap;">',
            '  <div style="min-width: 0; flex: 1;">',
            '    <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">',
            '      <strong>' + ELIPS.escapeHtml(item.title) + '</strong>',
            '      <span class="badge badge-primary">' + ELIPS.escapeHtml(MATERIAL_TYPE_LABELS[item.type] || item.type) + '</span>',
            '      <span class="badge">' + ELIPS.escapeHtml(MATERIAL_ACCESS_LABELS[item.accessLevel] || item.accessLevel) + '</span>',
            '      ' + materialStatusBadge(item.status),
            '    </div>',
            '    <div class="table-course-meta" style="margin-top: 0.25rem;">' + ELIPS.escapeHtml(relation) +
                (item.availableFrom ? ' &bull; Tersedia ' + ELIPS.escapeHtml(item.availableFrom) : '') + '</div>',
            item.description ? '    <div style="font-size: 0.8125rem; color: var(--text-secondary); margin-top: 0.25rem;">' + ELIPS.escapeHtml(item.description) + '</div>' : '',
            '  </div>',
            '  <div style="display: flex; gap: 0.25rem; flex-wrap: wrap;">',
            '    <button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="openMaterialModal(' + item.id + ')" title="Edit materi"><i class="bi bi-pencil"></i></button>',
            '    <button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="openMaterialStatusModal(' + item.id + ')" title="Ubah status"><i class="bi ' + (item.status === 'hidden' ? 'bi-eye' : 'bi-eye-slash') + '"></i></button>',
            '    <button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem; color: var(--danger);" onclick="deleteClassMaterialItem(' + item.id + ')" title="Hapus materi"><i class="bi bi-trash"></i></button>',
            '  </div>',
            '</div>'
        ].join('');
    }).join('') + '</div>';
}

function selectMaterialClass(classId) {
    selectedMaterialClassId = Number(classId);
    renderClassMaterials();
}

function refreshMaterialFields() {
    const type = document.getElementById('materialType').value;
    const label = document.getElementById('materialContentLabel');
    const content = document.getElementById('materialContent');
    const fileFields = document.getElementById('materialFileFields');
    if (type === 'text') {
        label.textContent = 'Konten Teks';
        content.placeholder = 'Tulis materi pelajaran di sini...';
    } else if (type === 'video') {
        label.textContent = 'URL Video';
        content.placeholder = 'https://youtube.com/watch?v=...';
    } else if (type === 'link') {
        label.textContent = 'URL Tujuan';
        content.placeholder = 'https://example.com/materi';
    } else {
        label.textContent = 'URL / Lokasi File';
        content.placeholder = 'https://... atau nama file';
    }
    fileFields.style.display = (type === 'file' || type === 'document') ? 'grid' : 'none';
}

function openMaterialModal(materialId) {
    if (!selectedMaterialClassId) {
        ELIPS.toast('Pilih kelas terlebih dahulu.');
        return;
    }
    const classItem = ELIPS.getClassById(selectedMaterialClassId);
    if (!classItem) return;
    const item = materialId ? ELIPS.getClassMaterialById(materialId) : null;
    editingMaterialId = item ? Number(item.id) : null;

    document.getElementById('materialModalTitle').textContent = item ? 'Edit Materi Tambahan' : 'Tambah Materi Tambahan';
    document.getElementById('materialId').value = item ? String(item.id) : '';
    document.getElementById('materialTitle').value = item ? item.title : '';
    document.getElementById('materialDescription').value = item ? (item.description || '') : '';
    document.getElementById('materialType').value = item ? item.type : 'text';
    document.getElementById('materialAccessLevel').value = item ? item.accessLevel : 'optional';
    document.getElementById('materialContent').value = item ? (item.content || '') : '';
    document.getElementById('materialFileName').value = item ? (item.fileName || '') : '';
    document.getElementById('materialFileSize').value = item && item.fileSize !== null ? item.fileSize : '';
    document.getElementById('materialMimeType').value = item ? (item.mimeType || '') : '';
    document.getElementById('materialAvailableFrom').value = item ? (item.availableFrom || '') : '';
    document.getElementById('materialOrder').value = item ? item.order : '';

    const lessonSelect = document.getElementById('materialLesson');
    lessonSelect.innerHTML = '<option value="">Tidak terkait pelajaran</option>' +
        classCurriculumLessons(classItem).map(function (lesson) {
            return '<option value="' + lesson.id + '" ' + (item && Number(item.lessonId) === Number(lesson.id) ? 'selected' : '') + '>' +
                ELIPS.escapeHtml(lesson.title) + '</option>';
        }).join('');

    const sessionSelect = document.getElementById('materialSession');
    sessionSelect.innerHTML = '<option value="">Tidak terkait sesi</option>' +
        ELIPS.getSessionsByClass(classItem.id).map(function (session) {
            return '<option value="' + session.id + '" ' + (item && Number(item.sessionId) === Number(session.id) ? 'selected' : '') + '>' +
                ELIPS.escapeHtml('Pertemuan ' + session.sessionNumber + ' • ' + (session.sessionDate || '')) + '</option>';
        }).join('');

    refreshMaterialFields();
    document.getElementById('materialModal').style.display = 'flex';
}

function closeMaterialModal() {
    document.getElementById('materialModal').style.display = 'none';
    editingMaterialId = null;
}

function saveMaterial() {
    if (!selectedMaterialClassId) return;
    const data = {
        title: document.getElementById('materialTitle').value.trim(),
        description: document.getElementById('materialDescription').value.trim(),
        type: document.getElementById('materialType').value,
        lessonId: document.getElementById('materialLesson').value || null,
        sessionId: document.getElementById('materialSession').value || null,
        content: document.getElementById('materialContent').value,
        fileName: document.getElementById('materialFileName').value.trim(),
        fileSize: document.getElementById('materialFileSize').value === '' ? null : Number(document.getElementById('materialFileSize').value),
        mimeType: document.getElementById('materialMimeType').value.trim(),
        accessLevel: document.getElementById('materialAccessLevel').value,
        availableFrom: document.getElementById('materialAvailableFrom').value || null,
        order: document.getElementById('materialOrder').value === '' ? 0 : Number(document.getElementById('materialOrder').value)
    };
    const result = editingMaterialId
        ? ELIPS.updateClassMaterial(editingMaterialId, data)
        : ELIPS.createClassMaterial(Object.assign({ classId: selectedMaterialClassId }, data));
    ELIPS.toast(result.message);
    if (result.ok) {
        closeMaterialModal();
        renderClassMaterials();
    }
}

function openMaterialStatusModal(materialId) {
    const item = ELIPS.getClassMaterialById(materialId);
    if (!item) return;
    const nextStatus = item.status === 'hidden' ? 'active' : 'hidden';
    document.getElementById('materialStatusId').value = String(item.id);
    document.getElementById('materialStatusValue').value = nextStatus;
    document.getElementById('materialStatusTitle').textContent =
        nextStatus === 'hidden' ? 'Sembunyikan Materi' : 'Aktifkan Materi';
    document.getElementById('materialStatusText').textContent =
        '"' + item.title + '" akan ' + (nextStatus === 'hidden' ? 'disembunyikan dari peserta' : 'ditampilkan kembali kepada peserta') + '. Alasan wajib diisi.';
    document.getElementById('materialStatusReason').value = '';
    document.getElementById('materialStatusModal').style.display = 'flex';
}

function closeMaterialStatusModal() {
    document.getElementById('materialStatusModal').style.display = 'none';
}

function saveMaterialStatus() {
    const materialId = Number(document.getElementById('materialStatusId').value);
    const status = document.getElementById('materialStatusValue').value;
    const reason = document.getElementById('materialStatusReason').value.trim();
    if (!reason) {
        ELIPS.toast('Alasan perubahan status materi wajib diisi.');
        return;
    }
    const result = ELIPS.setClassMaterialStatus(materialId, { status: status, reason: reason });
    ELIPS.toast(result.message);
    if (result.ok) {
        closeMaterialStatusModal();
        renderClassMaterials();
    }
}

function deleteClassMaterialItem(materialId) {
    const item = ELIPS.getClassMaterialById(materialId);
    if (!item) return;
    if (!confirm('Hapus materi tambahan "' + item.title + '"?')) return;
    const result = ELIPS.deleteClassMaterial(item.id);
    ELIPS.toast(result.message);
    if (result.ok) renderClassMaterials();
}

function fillCourseSelect(selectId, selectedId) {
    const select = document.getElementById(selectId);
    select.innerHTML = '';
    const courses = myCourses();

    if (courses.length === 0) {
        select.innerHTML = '<option value="">Belum ada kursus ditugaskan</option>';
        return;
    }

    courses.forEach(function (course) {
        const option = document.createElement('option');
        option.value = String(course.id);
        option.textContent = course.title + (course.status === 'published' ? '' : ' (Draft)');
        select.appendChild(option);
    });

    if (selectedId && courses.some(function (course) { return course.id === Number(selectedId); })) {
        select.value = String(selectedId);
    }
}

function openModuleModal(moduleId) {
    if (myCourses().length === 0) {
        ELIPS.toast('Belum ada kursus yang ditugaskan kepada Anda.');
        return;
    }

    const module = moduleId ? ELIPS.getModules().find(function (item) { return item.id === Number(moduleId); }) : null;
    editingModuleId = module ? module.id : null;

    fillCourseSelect('moduleCourse', module ? module.courseId : selectedCourseId);
    document.getElementById('moduleTitle').value = module ? module.title : '';
    document.getElementById('moduleDesc').value = module ? (module.description || '') : '';
    document.getElementById('moduleModalTitle').textContent = module ? 'Edit Modul' : 'Tambah Modul';
    document.getElementById('moduleSaveBtn').textContent = module ? 'Simpan Perubahan' : 'Simpan Modul';
    document.getElementById('moduleCourse').disabled = !!module;
    document.getElementById('moduleCourseHint').textContent = module
        ? 'Kursus tidak dapat dipindahkan saat mengedit modul.'
        : 'Pilih kursus yang Anda ampu.';
    document.getElementById('moduleModal').style.display = 'flex';
    document.getElementById('moduleTitle').focus();
}

function closeModuleModal() {
    document.getElementById('moduleModal').style.display = 'none';
    document.getElementById('moduleCourse').disabled = false;
    editingModuleId = null;
}

function saveModule() {
    if (!currentInstructor) return;

    const courseId = parseInt(document.getElementById('moduleCourse').value, 10);
    const payload = {
        title: document.getElementById('moduleTitle').value.trim(),
        description: document.getElementById('moduleDesc').value.trim()
    };

    const result = editingModuleId
        ? ELIPS.updateModule(editingModuleId, payload, currentInstructor.id)
        : ELIPS.createModule(courseId, payload, currentInstructor.id);

    if (!result.ok) {
        ELIPS.toast(result.message);
        return;
    }

    ELIPS.toast(result.message);
    const targetCourseId = result.data ? result.data.courseId : courseId;
    closeModuleModal();
    initInstructor(targetCourseId);
}

function refreshLessonModules(selectedModuleId) {
    const courseId = parseInt(document.getElementById('lessonCourse').value, 10);
    const select = document.getElementById('lessonModule');
    select.innerHTML = '';
    const modules = courseId ? ELIPS.getModulesByCourse(courseId) : [];

    if (modules.length === 0) {
        select.innerHTML = '<option value="">(Belum ada modul - buat modul dulu)</option>';
        return;
    }

    modules.forEach(function (module) {
        const option = document.createElement('option');
        option.value = String(module.id);
        option.textContent = module.title;
        select.appendChild(option);
    });

    if (selectedModuleId && modules.some(function (module) { return module.id === Number(selectedModuleId); })) {
        select.value = String(selectedModuleId);
    }
}

function openLessonModal(moduleId, lessonId) {
    if (myCourses().length === 0) {
        ELIPS.toast('Belum ada kursus yang ditugaskan kepada Anda.');
        return;
    }

    const lessons = ELIPS.getLessons();
    const lesson = lessonId ? lessons.find(function (item) { return item.id === Number(lessonId); }) : null;
    const module = moduleId
        ? ELIPS.getModules().find(function (item) { return item.id === Number(moduleId); })
        : (lesson ? ELIPS.getModules().find(function (item) { return item.id === lesson.moduleId; }) : null);

    editingLessonId = lesson ? lesson.id : null;
    const courseId = lesson ? lesson.courseId : (module ? module.courseId : selectedCourseId);

    if (!myCourses().some(function (course) { return course.id === Number(courseId); })) {
        ELIPS.toast('Anda tidak ditugaskan pada kursus ini.');
        return;
    }

    fillCourseSelect('lessonCourse', courseId);
    refreshLessonModules(module ? module.id : null);
    document.getElementById('lessonCourse').disabled = !!lesson;

    document.getElementById('lessonModalTitle').textContent = lesson ? 'Edit Pelajaran / Materi' : 'Tambah Pelajaran / Materi';
    document.getElementById('lessonSaveBtn').textContent = lesson ? 'Simpan Perubahan' : 'Simpan Pelajaran';
    document.getElementById('lessonTitle').value = lesson ? lesson.title : '';
    document.getElementById('contentType').value = lesson ? (lesson.type || 'text') : 'text';
    document.getElementById('lessonContent').value = lesson ? (lesson.content || '') : '';
    toggleContentFields();
    document.getElementById('lessonModal').style.display = 'flex';
    document.getElementById('lessonTitle').focus();
}

function closeLessonModal() {
    document.getElementById('lessonModal').style.display = 'none';
    document.getElementById('lessonCourse').disabled = false;
    editingLessonId = null;
}

function toggleContentFields() {
    const type = document.getElementById('contentType').value;
    const label = document.getElementById('contentLabel');
    const field = document.getElementById('lessonContent');

    if (type === 'text') {
        label.textContent = 'Konten Teks';
        field.placeholder = 'Tulis materi pelajaran di sini...';
        field.rows = 6;
    } else if (type === 'video') {
        label.textContent = 'URL Video (YouTube/Vimeo)';
        field.placeholder = 'https://www.youtube.com/watch?v=...';
        field.rows = 2;
    } else if (type === 'file') {
        label.textContent = 'Nama File / URL File';
        field.placeholder = 'materi-modul-1.pdf';
        field.rows = 2;
    } else {
        label.textContent = 'URL Link Eksternal';
        field.placeholder = 'https://...';
        field.rows = 2;
    }
}

function saveLesson() {
    if (!currentInstructor) return;

    const courseId = parseInt(document.getElementById('lessonCourse').value, 10);
    const moduleId = parseInt(document.getElementById('lessonModule').value, 10);
    const payload = {
        moduleId: moduleId,
        title: document.getElementById('lessonTitle').value.trim(),
        type: document.getElementById('contentType').value,
        content: document.getElementById('lessonContent').value.trim()
    };

    const result = editingLessonId
        ? ELIPS.updateLesson(editingLessonId, payload, currentInstructor.id)
        : ELIPS.createLesson(moduleId, payload, currentInstructor.id);

    if (!result.ok) {
        ELIPS.toast(result.message);
        return;
    }

    ELIPS.toast(result.message);
    const targetCourseId = result.data ? result.data.courseId : courseId;
    closeLessonModal();
    initInstructor(targetCourseId);
}

function deleteModule(moduleId) {
    const module = ELIPS.getModules().find(function (item) { return item.id === Number(moduleId); });
    if (!module) return;

    const lessonCount = ELIPS.getLessonsByModule(module.id).length;
    const message = 'Hapus modul "' + module.title + '"' +
        (lessonCount > 0 ? ' beserta ' + lessonCount + ' materinya?' : '?');
    if (!confirm(message)) return;

    const result = ELIPS.deleteModule(module.id, currentInstructor.id);
    ELIPS.toast(result.message);
    if (result.ok) initInstructor(module.courseId);
}

function deleteLesson(lessonId) {
    const lesson = ELIPS.getLessons().find(function (item) { return item.id === Number(lessonId); });
    if (!lesson) return;
    if (!confirm('Hapus materi "' + lesson.title + '"?')) return;

    const result = ELIPS.deleteLesson(lesson.id, currentInstructor.id);
    ELIPS.toast(result.message);
    if (result.ok) initInstructor(lesson.courseId);
}

// ---------- Tugas & ujian (Phase 5) ----------
function taskStatusBadge(status) {
    const map = { draft: 'badge-warning', published: 'badge-success', closed: 'badge-primary', archived: 'badge' };
    return '<span class="badge ' + (map[status] || 'badge') + '">' + ELIPS.escapeHtml(TASK_STATUS_LABELS[status] || status) + '</span>';
}

function submissionStatusBadge(status) {
    const map = {
        submitted: 'badge-primary', late: 'badge-warning', reviewed: 'badge-success',
        revision_requested: 'badge-warning', resubmitted: 'badge-primary', accepted: 'badge-success'
    };
    return '<span class="badge ' + (map[status] || 'badge') + '">' + ELIPS.escapeHtml(SUBMISSION_STATUS_LABELS[status] || status) + '</span>';
}

function formatTaskDateTime(value) {
    if (!value) return '-';
    const date = new Date(value);
    if (isNaN(date.getTime())) return ELIPS.escapeHtml(String(value));
    return date.toLocaleString('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function taskDateTimeInput(value) {
    if (!value) return '';
    const date = new Date(value);
    if (isNaN(date.getTime())) return '';
    const pad = function (n) { return String(n).padStart(2, '0'); };
    return date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate()) +
        'T' + pad(date.getHours()) + ':' + pad(date.getMinutes());
}

function formatFileSize(size) {
    const value = Number(size);
    if (!value || value < 0) return '';
    if (value >= 1048576) return (value / 1048576).toFixed(1) + ' MB';
    if (value >= 1024) return Math.round(value / 1024) + ' KB';
    return value + ' B';
}

function taskClassContext() {
    const course = selectedCourseId ? ELIPS.getCourseById(selectedCourseId) : null;
    if (!course) return null;
    const classes = manageableClassesForCourse(course.id);
    if (classes.length === 0) return { course: course, classes: [], classItem: null };
    const valid = selectedTaskClassId && classes.some(function (item) {
        return Number(item.id) === Number(selectedTaskClassId);
    });
    if (!valid) selectedTaskClassId = Number(classes[0].id);
    const classItem = classes.find(function (item) {
        return Number(item.id) === Number(selectedTaskClassId);
    });
    return { course: course, classes: classes, classItem: classItem };
}

function selectTaskClass(classId) {
    selectedTaskClassId = Number(classId);
    renderTasks();
}

function renderTasks() {
    const select = document.getElementById('taskClassSelect');
    const label = document.getElementById('taskClassLabel');
    const panel = document.getElementById('taskPanel');
    if (!select || !label || !panel) return;

    const context = taskClassContext();
    if (!context) {
        select.innerHTML = '<option value="">Pilih kursus terlebih dahulu</option>';
        label.textContent = 'Pilih kursus untuk mengelola tugas dan ujian';
        panel.innerHTML = '<p style="color: var(--text-secondary);">Pilih kursus yang ditugaskan.</p>';
        return;
    }
    if (!context.classItem) {
        select.innerHTML = '<option value="">Belum ada kelas yang Anda ampu</option>';
        label.textContent = 'Belum ada kelas untuk kursus ini';
        panel.innerHTML = '<p style="color: var(--text-secondary);">Admin belum menugaskan Anda pada kelas untuk kursus ini.</p>';
        return;
    }

    select.innerHTML = context.classes.map(function (item) {
        return '<option value="' + item.id + '" ' + (Number(item.id) === Number(selectedTaskClassId) ? 'selected' : '') + '>' +
            ELIPS.escapeHtml(item.name + ' (' + item.code + ')') + '</option>';
    }).join('');
    label.textContent = context.classItem.name + ' • ' + context.classItem.code;

    const result = ELIPS.getAssignmentClassroom({ classId: selectedTaskClassId });
    if (!result.ok) {
        panel.innerHTML = '<div style="padding: 1rem; border: 1px solid var(--danger); border-radius: var(--radius); color: var(--danger);">' +
            ELIPS.escapeHtml(result.message) + '</div>';
        return;
    }
    const payload = result.data || {};
    renderTaskPanel(payload.assignments || [], payload.exams || []);
}

function renderTaskPanel(assignments, exams) {
    const panel = document.getElementById('taskPanel');
    panel.innerHTML = [
        '<div style="margin-bottom: 1.25rem;">',
        '  <div style="display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap; margin-bottom: 0.5rem;">',
        '    <h3 style="font-size: 1rem; font-weight: 600; margin: 0;"><i class="bi bi-clipboard-check"></i> Tugas</h3>',
        '    <span class="badge badge-primary">' + assignments.length + ' Tugas</span>',
        '  </div>',
        renderAssignmentTable(assignments),
        '</div>',
        '<div>',
        '  <div style="display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap; margin-bottom: 0.5rem;">',
        '    <h3 style="font-size: 1rem; font-weight: 600; margin: 0;"><i class="bi bi-journal-check"></i> Ujian</h3>',
        '    <span class="badge badge-primary">' + exams.length + ' Ujian</span>',
        '  </div>',
        renderExamTable(exams),
        '</div>'
    ].join('');
}

function renderAssignmentTable(assignments) {
    if (assignments.length === 0) {
        return [
            '<div style="text-align: center; padding: 1.75rem 1rem; color: var(--text-secondary); border: 1px dashed var(--border); border-radius: var(--radius);">',
            '  <i class="bi bi-clipboard-plus" style="display: block; font-size: 2rem; opacity: .45; margin-bottom: .5rem;"></i>',
            '  <div style="font-weight: 600; color: var(--text-primary); margin-bottom: .25rem;">Belum ada tugas</div>',
            '  <div style="font-size: .875rem;">Gunakan tombol "Tambah Tugas" untuk membuat tugas pertama.</div>',
            '</div>'
        ].join('');
    }
    return '<div style="display: flex; flex-direction: column; gap: 0.75rem;">' + assignments.map(function (item) {
        const stats = item.stats || {};
        const dueText = item.dueAt ? 'Tenggat ' + formatTaskDateTime(item.dueAt) : 'Tanpa tenggat';
        const statText = (stats.submissionCount || 0) + ' terkumpul • ' + (stats.pendingCount || 0) + ' menunggu' +
            (stats.averageScore !== null && stats.averageScore !== undefined ? ' • rata-rata ' + stats.averageScore : '');
        return [
            '<div style="display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem; padding: 0.875rem 1rem; border: 1px solid var(--border); border-radius: var(--radius); flex-wrap: wrap;">',
            '  <div style="min-width: 0; flex: 1;">',
            '    <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">',
            '      <strong>' + ELIPS.escapeHtml(item.title) + '</strong>',
            '      <span class="badge">' + ELIPS.escapeHtml(ASSIGNMENT_TYPE_LABELS[item.type] || item.type) + '</span>',
            taskStatusBadge(item.status),
            '      <span class="badge">Bobot ' + (Number(item.weight) || 0) + '%</span>',
            '    </div>',
            '    <div class="table-course-meta" style="margin-top: 0.25rem;">' + ELIPS.escapeHtml(dueText) +
                (item.lessonTitle ? ' &bull; ' + ELIPS.escapeHtml(item.lessonTitle) : '') + '</div>',
            '    <div style="font-size: 0.8125rem; color: var(--text-secondary); margin-top: 0.25rem;">' + ELIPS.escapeHtml(statText) + '</div>',
            '  </div>',
            '  <div style="display: flex; gap: 0.25rem; flex-wrap: wrap;">',
            '    <button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="openAssignmentTaskModal(' + item.id + ')" title="Edit tugas"><i class="bi bi-pencil"></i></button>',
            '    <button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="openAssignmentSubmissions(' + item.id + ')" title="Pengumpulan"><i class="bi bi-inbox"></i></button>',
            assignmentStatusButton(item),
            '    <button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem; color: var(--danger);" onclick="deleteAssignmentTask(' + item.id + ')" title="Hapus tugas"><i class="bi bi-trash"></i></button>',
            '  </div>',
            '</div>'
        ].join('');
    }).join('') + '</div>';
}

function assignmentStatusButton(item) {
    if (item.status === 'draft') {
        return '<button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="setAssignmentTaskStatus(' + item.id + ', \'published\')" title="Publikasikan"><i class="bi bi-eye"></i></button>';
    }
    if (item.status === 'published') {
        return '<button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="setAssignmentTaskStatus(' + item.id + ', \'closed\')" title="Tutup tugas"><i class="bi bi-lock"></i></button>';
    }
    if (item.status === 'closed') {
        return '<button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="setAssignmentTaskStatus(' + item.id + ', \'archived\')" title="Arsipkan"><i class="bi bi-archive"></i></button>';
    }
    return '<button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="setAssignmentTaskStatus(' + item.id + ', \'draft\')" title="Kembalikan ke draft"><i class="bi bi-arrow-counterclockwise"></i></button>';
}

function renderExamTable(exams) {
    if (exams.length === 0) {
        return [
            '<div style="text-align: center; padding: 1.75rem 1rem; color: var(--text-secondary); border: 1px dashed var(--border); border-radius: var(--radius);">',
            '  <i class="bi bi-journal-plus" style="display: block; font-size: 2rem; opacity: .45; margin-bottom: .5rem;"></i>',
            '  <div style="font-weight: 600; color: var(--text-primary); margin-bottom: .25rem;">Belum ada ujian</div>',
            '  <div style="font-size: .875rem;">Gunakan tombol "Tambah Ujian" untuk menjadwalkan ujian.</div>',
            '</div>'
        ].join('');
    }
    return '<div style="display: flex; flex-direction: column; gap: 0.75rem;">' + exams.map(function (item) {
        const stats = item.stats || {};
        const dateText = item.examDate
            ? formatTaskDateTime(item.examDate + 'T' + (item.startTime || '00:00') + ':00')
            : 'Belum dijadwalkan';
        const statText = (stats.participantCount || 0) + ' peserta • ' + (stats.gradedCount || 0) + ' dinilai' +
            (stats.averageScore !== null && stats.averageScore !== undefined ? ' • rata-rata ' + stats.averageScore : '');
        return [
            '<div style="display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem; padding: 0.875rem 1rem; border: 1px solid var(--border); border-radius: var(--radius); flex-wrap: wrap;">',
            '  <div style="min-width: 0; flex: 1;">',
            '    <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">',
            '      <strong>' + ELIPS.escapeHtml(item.title) + '</strong>',
            '      <span class="badge">' + ELIPS.escapeHtml(EXAM_TYPE_LABELS[item.type] || item.type) + '</span>',
            taskStatusBadge(item.status),
            '      <span class="badge">Bobot ' + (Number(item.weight) || 0) + '%</span>',
            '    </div>',
            '    <div class="table-course-meta" style="margin-top: 0.25rem;">' + ELIPS.escapeHtml(dateText) +
                (item.durationMinutes ? ' &bull; ' + item.durationMinutes + ' menit' : '') + '</div>',
            '    <div style="font-size: 0.8125rem; color: var(--text-secondary); margin-top: 0.25rem;">' + ELIPS.escapeHtml(statText) + '</div>',
            '  </div>',
            '  <div style="display: flex; gap: 0.25rem; flex-wrap: wrap;">',
            '    <button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="openExamTaskModal(' + item.id + ')" title="Edit ujian"><i class="bi bi-pencil"></i></button>',
            '    <button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="openExamResults(' + item.id + ')" title="Hasil ujian"><i class="bi bi-list-check"></i></button>',
            examStatusButton(item),
            '    <button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem; color: var(--danger);" onclick="deleteExamTask(' + item.id + ')" title="Hapus ujian"><i class="bi bi-trash"></i></button>',
            '  </div>',
            '</div>'
        ].join('');
    }).join('') + '</div>';
}

function examStatusButton(item) {
    if (item.status === 'draft') {
        return '<button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="setExamTaskStatus(' + item.id + ', \'published\')" title="Publikasikan"><i class="bi bi-eye"></i></button>';
    }
    if (item.status === 'published') {
        return '<button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="setExamTaskStatus(' + item.id + ', \'closed\')" title="Tutup ujian"><i class="bi bi-lock"></i></button>';
    }
    if (item.status === 'closed') {
        return '<button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="setExamTaskStatus(' + item.id + ', \'archived\')" title="Arsipkan"><i class="bi bi-archive"></i></button>';
    }
    return '<button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="setExamTaskStatus(' + item.id + ', \'draft\')" title="Kembalikan ke draft"><i class="bi bi-arrow-counterclockwise"></i></button>';
}

function setAssignmentTaskStatus(id, status) {
    const result = ELIPS.updateAssignmentStatus(id, status, '');
    ELIPS.toast(result.message);
    if (result.ok) renderTasks();
}

function setExamTaskStatus(id, status) {
    const result = ELIPS.updateExamStatus(id, status, '');
    ELIPS.toast(result.message);
    if (result.ok) renderTasks();
}

function deleteAssignmentTask(id) {
    const item = ELIPS.getAssignmentById(id);
    if (!item) return;
    if (!confirm('Hapus tugas "' + item.title + '" beserta seluruh pengumpulannya?')) return;
    const result = ELIPS.deleteAssignment(id);
    ELIPS.toast(result.message);
    if (result.ok) renderTasks();
}

function deleteExamTask(id) {
    const item = ELIPS.getExamById(id);
    if (!item) return;
    if (!confirm('Hapus ujian "' + item.title + '" beserta hasil pesertanya?')) return;
    const result = ELIPS.deleteExam(id);
    ELIPS.toast(result.message);
    if (result.ok) renderTasks();
}

function refreshAssignmentTaskModules(selectedModuleId) {
    const select = document.getElementById('assignmentTaskModule');
    if (!select) return;
    const classItem = selectedTaskClassId ? ELIPS.getClassById(selectedTaskClassId) : null;
    const modules = classItem ? ELIPS.getModules()
        .filter(function (module) {
            return Number(module.courseId) === Number(classItem.courseId) &&
                Number(module.curriculumVersionId) === Number(classItem.curriculumVersionId);
        })
        .sort(function (a, b) { return (Number(a.order) || 0) - (Number(b.order) || 0); }) : [];
    select.innerHTML = '<option value="">Tanpa modul</option>' + modules.map(function (module) {
        return '<option value="' + module.id + '" ' +
            (selectedModuleId && Number(selectedModuleId) === Number(module.id) ? 'selected' : '') + '>' +
            ELIPS.escapeHtml(module.title) + '</option>';
    }).join('');
}

function refreshAssignmentTaskLessons(selectedLessonId) {
    const select = document.getElementById('assignmentTaskLesson');
    if (!select) return;
    const moduleId = document.getElementById('assignmentTaskModule').value;
    const classItem = selectedTaskClassId ? ELIPS.getClassById(selectedTaskClassId) : null;
    const lessons = classItem && moduleId ? ELIPS.getLessons()
        .filter(function (lesson) {
            return Number(lesson.moduleId) === Number(moduleId) &&
                Number(lesson.courseId) === Number(classItem.courseId) &&
                Number(lesson.curriculumVersionId) === Number(classItem.curriculumVersionId);
        })
        .sort(function (a, b) { return (Number(a.order) || 0) - (Number(b.order) || 0); }) : [];
    select.innerHTML = '<option value="">Tanpa pelajaran</option>' + lessons.map(function (lesson) {
        return '<option value="' + lesson.id + '" ' +
            (selectedLessonId && Number(selectedLessonId) === Number(lesson.id) ? 'selected' : '') + '>' +
            ELIPS.escapeHtml(lesson.title) + '</option>';
    }).join('');
}

function addAssignmentRubricRow(rubric) {
    const container = document.getElementById('assignmentTaskRubrics');
    if (!container) return;
    const row = document.createElement('div');
    row.className = 'assignment-rubric-row';
    row.style.cssText = 'display: grid; grid-template-columns: 1.2fr 1.6fr 90px 36px; gap: 0.5rem; align-items: start;';
    row.innerHTML = [
        '<input type="text" class="form-input rubric-criterion" placeholder="Kriteria" value="' + ELIPS.escapeHtml(rubric ? rubric.criterion : '') + '">',
        '<input type="text" class="form-input rubric-description" placeholder="Deskripsi" value="' + ELIPS.escapeHtml(rubric ? (rubric.description || '') : '') + '">',
        '<input type="number" class="form-input rubric-max-score" min="1" step="0.01" placeholder="Nilai" value="' + (rubric ? Number(rubric.maxScore) || '' : '') + '">',
        '<button type="button" class="btn btn-ghost" style="padding: 0.5rem; color: var(--danger);" title="Hapus kriteria" onclick="removeAssignmentRubricRow(this)"><i class="bi bi-x-lg"></i></button>'
    ].join('');
    container.appendChild(row);
}

function removeAssignmentRubricRow(button) {
    const row = button.closest('.assignment-rubric-row');
    if (row) row.remove();
}

function collectAssignmentRubrics() {
    const rows = document.querySelectorAll('#assignmentTaskRubrics .assignment-rubric-row');
    const rubrics = [];
    Array.prototype.forEach.call(rows, function (row, index) {
        const criterion = row.querySelector('.rubric-criterion').value.trim();
        const description = row.querySelector('.rubric-description').value.trim();
        const maxScore = Number(row.querySelector('.rubric-max-score').value);
        if (criterion === '' && !maxScore) return;
        rubrics.push({ criterion: criterion, description: description, maxScore: maxScore, order: index + 1 });
    });
    return rubrics;
}

function openAssignmentTaskModal(assignmentId) {
    if (!selectedTaskClassId) {
        ELIPS.toast('Pilih kelas terlebih dahulu.');
        return;
    }
    if (!ELIPS.getClassById(selectedTaskClassId)) return;

    const detail = assignmentId ? ELIPS.getAssignmentDetail({ id: assignmentId }) : null;
    if (assignmentId && (!detail || !detail.ok)) {
        ELIPS.toast(detail ? detail.message : 'Tugas tidak ditemukan.');
        return;
    }
    const item = detail ? detail.data : null;
    editingAssignmentTaskId = item ? Number(item.id) : null;

    document.getElementById('assignmentTaskModalTitle').textContent = item ? 'Edit Tugas' : 'Tambah Tugas';
    document.getElementById('assignmentTaskId').value = item ? String(item.id) : '';
    document.getElementById('assignmentTaskTitle').value = item ? item.title : '';
    document.getElementById('assignmentTaskType').value = item ? item.type : 'text_submission';
    document.getElementById('assignmentTaskStatus').value = item ? item.status : 'draft';
    document.getElementById('assignmentTaskOpenAt').value = item ? taskDateTimeInput(item.openAt) : '';
    document.getElementById('assignmentTaskDueAt').value = item ? taskDateTimeInput(item.dueAt) : '';
    document.getElementById('assignmentTaskMaxScore').value = item ? item.maxScore : 100;
    document.getElementById('assignmentTaskWeight').value = item ? item.weight : 0;
    document.getElementById('assignmentTaskMaxFileSize').value = item && item.maxFileSize !== null && item.maxFileSize !== undefined ? item.maxFileSize : '';
    document.getElementById('assignmentTaskAllowedTypes').value = item ? (item.allowedTypes || '') : '';
    document.getElementById('assignmentTaskRequireFile').checked = item ? !!item.requireFile : false;
    document.getElementById('assignmentTaskInstructions').value = item ? (item.instructions || '') : '';

    refreshAssignmentTaskModules(item ? item.moduleId : null);
    refreshAssignmentTaskLessons(item ? item.lessonId : null);

    const rubricContainer = document.getElementById('assignmentTaskRubrics');
    rubricContainer.innerHTML = '';
    (item && item.rubrics ? item.rubrics : []).forEach(function (rubric) {
        addAssignmentRubricRow(rubric);
    });

    document.getElementById('assignmentTaskModal').style.display = 'flex';
    document.getElementById('assignmentTaskTitle').focus();
}

function closeAssignmentTaskModal() {
    document.getElementById('assignmentTaskModal').style.display = 'none';
    editingAssignmentTaskId = null;
}

function saveAssignmentTask() {
    if (!selectedTaskClassId) return;
    const data = {
        title: document.getElementById('assignmentTaskTitle').value.trim(),
        type: document.getElementById('assignmentTaskType').value,
        status: document.getElementById('assignmentTaskStatus').value,
        moduleId: document.getElementById('assignmentTaskModule').value || null,
        lessonId: document.getElementById('assignmentTaskLesson').value || null,
        openAt: document.getElementById('assignmentTaskOpenAt').value || null,
        dueAt: document.getElementById('assignmentTaskDueAt').value || null,
        maxScore: Number(document.getElementById('assignmentTaskMaxScore').value),
        weight: Number(document.getElementById('assignmentTaskWeight').value),
        requireFile: document.getElementById('assignmentTaskRequireFile').checked,
        allowedTypes: document.getElementById('assignmentTaskAllowedTypes').value.trim(),
        maxFileSize: document.getElementById('assignmentTaskMaxFileSize').value === ''
            ? null : Number(document.getElementById('assignmentTaskMaxFileSize').value),
        instructions: document.getElementById('assignmentTaskInstructions').value.trim(),
        rubrics: collectAssignmentRubrics()
    };
    const result = editingAssignmentTaskId
        ? ELIPS.updateAssignment(editingAssignmentTaskId, data)
        : ELIPS.createAssignment(Object.assign({ classId: selectedTaskClassId }, data));
    ELIPS.toast(result.message);
    if (result.ok) {
        closeAssignmentTaskModal();
        renderTasks();
    }
}

function openAssignmentSubmissions(assignmentId) {
    const result = ELIPS.getAssignmentSubmissions(assignmentId);
    if (!result.ok) {
        ELIPS.toast(result.message);
        return;
    }
    openSubmissionsAssignmentId = Number(assignmentId);
    submissionsCache = result.data;
    renderAssignmentSubmissionsModal();
    document.getElementById('assignmentSubmissionsModal').style.display = 'flex';
}

function closeAssignmentSubmissionsModal() {
    document.getElementById('assignmentSubmissionsModal').style.display = 'none';
    openSubmissionsAssignmentId = null;
    submissionsCache = null;
}

function refreshSubmissionsCache() {
    if (!openSubmissionsAssignmentId) return;
    const result = ELIPS.getAssignmentSubmissions(openSubmissionsAssignmentId);
    if (result.ok) submissionsCache = result.data;
    renderAssignmentSubmissionsModal();
}

function renderAssignmentSubmissionsModal() {
    const body = document.getElementById('assignmentSubmissionsBody');
    if (!submissionsCache) {
        body.innerHTML = '';
        return;
    }
    const assignment = submissionsCache.assignment || {};
    const stats = submissionsCache.stats || {};
    document.getElementById('assignmentSubmissionsTitle').textContent = 'Pengumpulan: ' + (assignment.title || '');
    const students = submissionsCache.students || [];

    body.innerHTML = [
        '<div style="display: flex; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 1rem;">',
        '  <span class="badge badge-primary">' + (stats.submissionCount || 0) + ' Terkumpul</span>',
        '  <span class="badge badge-warning">' + (stats.pendingCount || 0) + ' Menunggu</span>',
        '  <span class="badge badge-success">' + (stats.reviewedCount || 0) + ' Dinilai</span>',
        '  <span class="badge">' + (stats.lateCount || 0) + ' Terlambat</span>',
        stats.averageScore !== null && stats.averageScore !== undefined
            ? '  <span class="badge">Rata-rata ' + stats.averageScore + '</span>' : '',
        '</div>',
        students.length === 0
            ? '<p style="color: var(--text-secondary);">Belum ada peserta aktif pada kelas ini.</p>'
            : '<div style="overflow-x: auto;"><table class="dashboard-table"><thead><tr>' +
                '<th>Peserta</th><th>Status</th><th>Dikumpulkan</th><th>Nilai</th><th>Aksi</th>' +
                '</tr></thead><tbody>' + students.map(function (row) {
                    const submission = row.submission;
                    return [
                        '<tr>',
                        '  <td>' + ELIPS.escapeHtml(row.studentName) + '</td>',
                        '  <td>' + (submission ? submissionStatusBadge(submission.status) : '<span class="badge">Belum</span>') + '</td>',
                        '  <td>' + (submission ? formatTaskDateTime(submission.submittedAt) + (submission.isLate ? ' <span class="badge badge-warning">Terlambat</span>' : '') : '-') + '</td>',
                        '  <td>' + (submission && submission.score !== null && submission.score !== undefined ? submission.score : '-') + '</td>',
                        '  <td>' + (submission
                            ? '<button class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="openSubmissionReview(' + row.enrollmentId + ')" title="Periksa"><i class="bi bi-search"></i> Periksa</button>'
                            : '<span style="color: var(--text-secondary); font-size: 0.75rem;">Belum mengumpulkan</span>') + '</td>',
                        '</tr>'
                    ].join('');
                }).join('') + '</tbody></table></div>',
        '<div id="submissionReviewPanel" style="margin-top: 1rem;"></div>'
    ].join('');
}

function openSubmissionReview(enrollmentId) {
    if (!openSubmissionsAssignmentId) return;
    const result = ELIPS.getAssignmentDetail({
        id: openSubmissionsAssignmentId,
        enrollmentId: enrollmentId
    });
    if (!result.ok) {
        ELIPS.toast(result.message);
        return;
    }
    const detail = result.data;
    const submission = detail ? detail.submission : null;
    const panel = document.getElementById('submissionReviewPanel');
    if (!panel) return;
    if (!submission) {
        panel.innerHTML = '<p style="color: var(--text-secondary);">Peserta ini belum mengumpulkan tugas.</p>';
        return;
    }

    const files = (submission.files || []).map(function (file) {
        return '<li>' + ELIPS.escapeHtml(file.fileName) +
            (file.fileSize ? ' <span style="color: var(--text-secondary);">(' + formatFileSize(file.fileSize) + ')</span>' : '') + '</li>';
    }).join('');
    const reviews = (submission.reviews || []).map(function (review) {
        return '<li><strong>' + ELIPS.escapeHtml(review.action) + '</strong>' +
            (review.score !== null && review.score !== undefined ? ' • nilai ' + review.score : '') +
            (review.note ? ' — ' + ELIPS.escapeHtml(review.note) : '') +
            ' <span style="color: var(--text-secondary);">(' + formatTaskDateTime(review.createdAt) + ')</span></li>';
    }).join('');

    panel.innerHTML = [
        '<div style="padding: 1rem; border: 1px solid var(--border); border-radius: var(--radius);">',
        '  <div style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 0.75rem;">',
        '    <strong>' + ELIPS.escapeHtml(submission.studentName || 'Peserta') + '</strong>',
        submissionStatusBadge(submission.status),
        '  </div>',
        submission.textAnswer
            ? '  <div style="white-space: pre-wrap; background: var(--background); padding: 0.75rem; border-radius: var(--radius); font-size: 0.875rem; margin-bottom: 0.75rem;">' + ELIPS.escapeHtml(submission.textAnswer) + '</div>'
            : '',
        files ? '  <div style="font-size: 0.875rem; margin-bottom: 0.75rem;"><strong>File:</strong><ul style="margin: 0.25rem 0 0 1rem;">' + files + '</ul></div>' : '',
        submission.feedback
            ? '  <div style="font-size: 0.875rem; margin-bottom: 0.75rem;"><strong>Umpan balik terakhir:</strong> ' + ELIPS.escapeHtml(submission.feedback) + '</div>'
            : '',
        reviews ? '  <div style="font-size: 0.875rem; margin-bottom: 0.75rem;"><strong>Riwayat:</strong><ul style="margin: 0.25rem 0 0 1rem;">' + reviews + '</ul></div>' : '',
        '  <div style="display: grid; grid-template-columns: 1fr 1fr 2fr; gap: 0.5rem; align-items: end;">',
        '    <div class="form-group" style="margin: 0;">',
        '      <label class="form-label" for="submissionReviewAction">Aksi</label>',
        '      <select id="submissionReviewAction" class="form-input">',
        '        <option value="score">Beri Nilai</option>',
        '        <option value="revision">Minta Revisi</option>',
        '        <option value="accept">Terima</option>',
        '      </select>',
        '    </div>',
        '    <div class="form-group" style="margin: 0;">',
        '      <label class="form-label" for="submissionReviewScore">Nilai (maks ' + (Number(submission.maxScore) || 0) + ')</label>',
        '      <input type="number" id="submissionReviewScore" class="form-input" min="0" step="0.01" value="' +
            (submission.score !== null && submission.score !== undefined ? submission.score : '') + '">',
        '    </div>',
        '    <div class="form-group" style="margin: 0;">',
        '      <label class="form-label" for="submissionReviewNote">Catatan / Umpan Balik</label>',
        '      <input type="text" id="submissionReviewNote" class="form-input" value="' + ELIPS.escapeHtml(submission.feedback || '') + '">',
        '    </div>',
        '  </div>',
        '  <div style="margin-top: 0.75rem; text-align: right;">',
        '    <button class="btn btn-primary" onclick="saveSubmissionReview(' + submission.id + ')"><i class="bi bi-save"></i> Simpan Penilaian</button>',
        '  </div>',
        '</div>'
    ].join('');
}

function saveSubmissionReview(submissionId) {
    const action = document.getElementById('submissionReviewAction').value;
    const scoreValue = document.getElementById('submissionReviewScore').value;
    const note = document.getElementById('submissionReviewNote').value.trim();
    const result = ELIPS.reviewSubmission(submissionId, {
        action: action,
        score: scoreValue === '' ? null : Number(scoreValue),
        note: note,
        feedback: note
    });
    ELIPS.toast(result.message);
    if (result.ok) {
        refreshSubmissionsCache();
        renderTasks();
    }
}

function openExamTaskModal(examId) {
    if (!selectedTaskClassId) {
        ELIPS.toast('Pilih kelas terlebih dahulu.');
        return;
    }
    const detail = examId ? ELIPS.getExamDetail({ id: examId }) : null;
    if (examId && (!detail || !detail.ok)) {
        ELIPS.toast(detail ? detail.message : 'Ujian tidak ditemukan.');
        return;
    }
    const item = detail ? detail.data : null;
    editingExamTaskId = item ? Number(item.id) : null;

    document.getElementById('examTaskModalTitle').textContent = item ? 'Edit Ujian' : 'Tambah Ujian';
    document.getElementById('examTaskId').value = item ? String(item.id) : '';
    document.getElementById('examTaskTitle').value = item ? item.title : '';
    document.getElementById('examTaskType').value = item ? item.type : 'written';
    document.getElementById('examTaskStatus').value = item ? item.status : 'draft';
    document.getElementById('examTaskDate').value = item && item.examDate ? String(item.examDate).slice(0, 10) : '';
    document.getElementById('examTaskStartTime').value = item && item.startTime ? String(item.startTime).slice(0, 5) : '';
    document.getElementById('examTaskDuration').value = item && item.durationMinutes !== null && item.durationMinutes !== undefined ? item.durationMinutes : '';
    document.getElementById('examTaskMaxScore').value = item ? item.maxScore : 100;
    document.getElementById('examTaskWeight').value = item ? item.weight : 0;
    document.getElementById('examTaskDescription').value = item ? (item.description || '') : '';
    document.getElementById('examTaskInstructions').value = item ? (item.instructions || '') : '';

    document.getElementById('examTaskModal').style.display = 'flex';
    document.getElementById('examTaskTitle').focus();
}

function closeExamTaskModal() {
    document.getElementById('examTaskModal').style.display = 'none';
    editingExamTaskId = null;
}

function saveExamTask() {
    if (!selectedTaskClassId) return;
    const data = {
        title: document.getElementById('examTaskTitle').value.trim(),
        type: document.getElementById('examTaskType').value,
        status: document.getElementById('examTaskStatus').value,
        examDate: document.getElementById('examTaskDate').value || null,
        startTime: document.getElementById('examTaskStartTime').value || null,
        durationMinutes: document.getElementById('examTaskDuration').value === ''
            ? null : Number(document.getElementById('examTaskDuration').value),
        maxScore: Number(document.getElementById('examTaskMaxScore').value),
        weight: Number(document.getElementById('examTaskWeight').value),
        description: document.getElementById('examTaskDescription').value.trim(),
        instructions: document.getElementById('examTaskInstructions').value.trim()
    };
    const result = editingExamTaskId
        ? ELIPS.updateExam(editingExamTaskId, data)
        : ELIPS.createExam(Object.assign({ classId: selectedTaskClassId }, data));
    ELIPS.toast(result.message);
    if (result.ok) {
        closeExamTaskModal();
        renderTasks();
    }
}

function openExamResults(examId) {
    const result = ELIPS.getExamDetail({ id: examId });
    if (!result.ok) {
        ELIPS.toast(result.message);
        return;
    }
    openExamResultsId = Number(examId);
    examResultsCache = result.data;
    renderExamResultsModal();
    document.getElementById('examResultsModal').style.display = 'flex';
}

function closeExamResultsModal() {
    document.getElementById('examResultsModal').style.display = 'none';
    openExamResultsId = null;
    examResultsCache = null;
}

function refreshExamResultsCache() {
    if (!openExamResultsId) return;
    const result = ELIPS.getExamDetail({ id: openExamResultsId });
    if (result.ok) examResultsCache = result.data;
    renderExamResultsModal();
}

function renderExamResultsModal() {
    const body = document.getElementById('examResultsBody');
    if (!examResultsCache) {
        body.innerHTML = '';
        return;
    }
    const exam = examResultsCache;
    document.getElementById('examResultsTitle').textContent = 'Hasil Ujian: ' + (exam.title || '');
    const results = exam.results || [];
    const participants = exam.participants || [];
    const stats = exam.stats || {};

    body.innerHTML = [
        '<div style="display: flex; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 1rem;">',
        '  <span class="badge badge-primary">' + (stats.participantCount || 0) + ' Peserta</span>',
        '  <span class="badge badge-success">' + (stats.attendedCount || 0) + ' Hadir</span>',
        '  <span class="badge badge-warning">' + (stats.absentCount || 0) + ' Tidak Hadir</span>',
        '  <span class="badge">' + (stats.gradedCount || 0) + ' Dinilai</span>',
        stats.averageScore !== null && stats.averageScore !== undefined
            ? '  <span class="badge">Rata-rata ' + stats.averageScore + '</span>' : '',
        '</div>',
        results.length === 0
            ? '<p style="color: var(--text-secondary);">Belum ada peserta ujian.</p>'
            : '<table class="dashboard-table"><thead><tr>' +
                '<th>Peserta</th><th>Keikutsertaan</th><th>Status Hasil</th><th>Nilai</th><th>Catatan</th><th></th>' +
                '</tr></thead><tbody>' + results.map(function (row) {
                    const participant = participants.find(function (p) {
                        return Number(p.enrollmentId) === Number(row.enrollmentId);
                    });
                    const participantStatus = participant ? participant.status : 'registered';
                    return [
                        '<tr>',
                        '  <td>' + ELIPS.escapeHtml(row.studentName) + '</td>',
                        '  <td><select id="examParticipantStatus_' + row.enrollmentId + '" class="form-input" style="min-width: 110px;">' +
                            Object.keys(PARTICIPANT_STATUS_LABELS).map(function (key) {
                                return '<option value="' + key + '" ' + (key === participantStatus ? 'selected' : '') + '>' +
                                    PARTICIPANT_STATUS_LABELS[key] + '</option>';
                            }).join('') + '</select></td>',
                        '  <td><select id="examResultStatus_' + row.enrollmentId + '" class="form-input" style="min-width: 130px;">' +
                            Object.keys(RESULT_STATUS_LABELS).map(function (key) {
                                return '<option value="' + key + '" ' + (key === row.status ? 'selected' : '') + '>' +
                                    RESULT_STATUS_LABELS[key] + '</option>';
                            }).join('') + '</select></td>',
                        '  <td><input type="number" id="examResultScore_' + row.enrollmentId + '" class="form-input" style="width: 90px;" min="0" max="' +
                            (Number(exam.maxScore) || 100) + '" step="0.01" value="' +
                            (row.score !== null && row.score !== undefined ? row.score : '') + '"></td>',
                        '  <td><input type="text" id="examResultNote_' + row.enrollmentId + '" class="form-input" style="min-width: 160px;" value="' +
                            ELIPS.escapeHtml(row.note || '') + '"></td>',
                        '  <td><button class="btn btn-primary" style="padding: 0.375rem 0.625rem; font-size: 0.75rem;" onclick="saveExamResultRow(' +
                            exam.id + ', ' + row.enrollmentId + ')"><i class="bi bi-save"></i></button></td>',
                        '</tr>'
                    ].join('');
                }).join('') + '</tbody></table>'
    ].join('');
}

function saveExamResultRow(examId, enrollmentId) {
    const scoreValue = document.getElementById('examResultScore_' + enrollmentId).value;
    const result = ELIPS.saveExamResult(examId, {
        enrollmentId: enrollmentId,
        data: {
            score: scoreValue === '' ? null : Number(scoreValue),
            status: document.getElementById('examResultStatus_' + enrollmentId).value,
            note: document.getElementById('examResultNote_' + enrollmentId).value.trim(),
            participantStatus: document.getElementById('examParticipantStatus_' + enrollmentId).value
        }
    });
    ELIPS.toast(result.message);
    if (result.ok) {
        refreshExamResultsCache();
        renderTasks();
    }
}


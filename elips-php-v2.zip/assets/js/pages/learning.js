// ELIPS LMS - skrip halaman learning.php
// Diekstrak dari inline <script>; URL relatif terhadap halaman.
let activeCourse = null;
let activeStudent = null;
let activeEnrollment = null;
let activeClassId = null;
let classroom = null;
let flatLessons = [];
let activeLessonId = null;
let activeMaterialId = null;
let canBypassLock = false;
let isPreviewMode = false;
let taskClassroom = null;
let activeAssignmentId = null;
let activeExamId = null;
let assignmentDetail = null;
let examDetail = null;
let pendingSubmissionFiles = [];
let transcriptMode = false;

const TASK_ASSIGNMENT_TYPE_LABELS = {
    file_upload: 'Unggah File',
    text_submission: 'Jawaban Teks',
    in_class_practice: 'Praktik Kelas',
    external_reference: 'Referensi Eksternal'
};
const TASK_STATUS_LABELS = {
    draft: 'Draft',
    published: 'Published',
    closed: 'Closed',
    archived: 'Archived'
};
const TASK_SUBMISSION_LABELS = {
    submitted: 'Dikumpulkan',
    late: 'Terlambat',
    reviewed: 'Dinilai',
    revision_requested: 'Minta Revisi',
    resubmitted: 'Dikumpulkan Ulang',
    accepted: 'Diterima'
};
const TASK_EXAM_TYPE_LABELS = {
    written: 'Tertulis',
    practical: 'Praktik',
    oral: 'Lisan',
    project: 'Proyek',
    other: 'Lainnya'
};
const TASK_RESULT_LABELS = {
    not_assessed: 'Belum Dinilai',
    excused: 'Izin',
    missing: 'Tidak Ada Nilai',
    graded: 'Dinilai'
};

document.addEventListener('DOMContentLoaded', initLearning);

function initLearning() {
    const params = new URLSearchParams(window.location.search);
    activeStudent = ELIPS.getCurrentUser();

    if (!activeStudent) {
        renderBlocked('Sesi tidak ditemukan', 'Silakan masuk terlebih dahulu untuk mengakses materi.');
        return;
    }

    isPreviewMode = activeStudent.role === 'instruktur' || activeStudent.role === 'admin';

    const backLink = document.getElementById('learningBackLink');
    if (backLink) backLink.href = ELIPS.dashboardPathForRole(activeStudent.role);

    const requestedId = parseInt(params.get('id') || params.get('courseId'), 10);
    let courseId = requestedId;

    if (!courseId) {
        const enrollments = ELIPS.getEnrollmentsByStudent(activeStudent.id).filter(function (e) { return e.status === 'active'; });
        courseId = enrollments.length > 0 ? enrollments[0].courseId : null;
    }

    if (!courseId) {
        renderBlocked('Belum Ada Kursus', 'Anda belum ditugaskan ke kursus mana pun. Hubungi Admin untuk mendapatkan penugasan.');
        return;
    }

    activeCourse = ELIPS.getCourseById(courseId);
    if (!activeCourse) {
        renderBlocked('Kursus Tidak Ditemukan', 'Kursus yang Anda cari tidak tersedia.');
        return;
    }

    document.getElementById('learningCourseTitle').textContent = activeCourse.title;

    if (isPreviewMode) {
        const backLink = document.getElementById('learningBackLink');
        if (backLink) {
            backLink.href = activeStudent.role === 'instruktur'
                ? 'instructor/manage-course.php?course=' + activeCourse.id
                : 'admin/courses.php';
            const label = backLink.querySelector('span');
            if (label) label.textContent = 'Kembali ke Kelola Kursus';
        }
    }

    activeEnrollment = ELIPS.getEnrollment(activeStudent.id, courseId);
    const isPrivileged = activeStudent.role === 'admin' ||
        (activeStudent.role === 'instruktur' && activeCourse.instructorId === activeStudent.id);
    canBypassLock = isPrivileged;

    if (!isPrivileged) {
        if (!activeEnrollment || activeEnrollment.status !== 'active') {
            renderBlocked('Akses Ditolak', 'Anda tidak terdaftar pada kursus ini. Siswa hanya dapat mengakses kursus yang ditugaskan oleh Admin.');
            return;
        }
        if (activeCourse.status !== 'published') {
            renderBlocked('Kursus Belum Dibuka', 'Kursus ini masih berstatus Draft. Silakan hubungi Admin untuk informasi lebih lanjut.');
            return;
        }
    }

    // Phase 4: gunakan konteks kelas bila tersedia agar mode akses
    // dan materi tambahan mengikuti pengaturan kelas, bukan kursus.
    if (isPrivileged) {
        let classes = ELIPS.getClassesByCourse(courseId);
        if (activeStudent.role === 'instruktur') {
            const mine = classes.filter(function (item) {
                return Number(item.instructorId) === Number(activeStudent.id);
            });
            if (mine.length > 0) classes = mine;
        }
        if (classes.length > 0) activeClassId = Number(classes[0].id);
    } else if (activeEnrollment && activeEnrollment.classId) {
        activeClassId = Number(activeEnrollment.classId);
    }

    if (activeClassId) {
        if (!loadClassroom()) return;
        buildFlatLessonsFromClassroom();
        loadTaskClassroom();
    } else {
        flatLessons = [];
        ELIPS.getCourseStructure(courseId).forEach(function (item) {
            item.lessons.forEach(function (lesson) {
                flatLessons.push({ lesson: lesson, module: item.module });
            });
        });
    }

    const hasContent = flatLessons.length > 0 || (classroom && classroom.materials.length > 0) ||
        (taskClassroom && (taskClassroom.assignments.length > 0 || taskClassroom.exams.length > 0));
    if (!hasContent) {
        renderBlocked('Materi Belum Tersedia', 'Instruktur belum menambahkan modul atau materi untuk kursus ini.');
        return;
    }

    const requestedLesson = parseInt(params.get('lesson'), 10);
    const firstUnlocked = flatLessons.find(function (entry) {
        return !isLessonCompleted(entry.lesson.id);
    });
    const fallbackLesson = firstUnlocked ? firstUnlocked.lesson.id : (flatLessons[0] ? flatLessons[0].lesson.id : null);
    const requestedValid = requestedLesson && flatLessons.some(function (e) { return e.lesson.id === requestedLesson; });

    if (requestedValid && lessonUnlocked(requestedLesson)) {
        activeLessonId = requestedLesson;
    } else if (requestedValid) {
        activeLessonId = fallbackLesson;
        ELIPS.toast('Materi tersebut masih terkunci. Selesaikan prasyaratnya terlebih dahulu.');
    } else {
        activeLessonId = fallbackLesson;
    }

    const requestedMaterial = parseInt(params.get('material'), 10);
    if (requestedMaterial && classroom && classroom.materials.some(function (item) { return item.id === requestedMaterial; })) {
        if (materialUnlocked(requestedMaterial)) {
            activeMaterialId = requestedMaterial;
            activeLessonId = null;
        } else {
            ELIPS.toast('Materi tambahan tersebut masih terkunci.');
        }
    }

    const requestedAssignment = parseInt(params.get('assignment'), 10);
    if (requestedAssignment && taskClassroom && taskClassroom.assignments.some(function (item) { return Number(item.id) === requestedAssignment; })) {
        if (loadAssignmentDetail(requestedAssignment)) {
            activeAssignmentId = requestedAssignment;
            activeLessonId = null;
            activeMaterialId = null;
        }
    }

    const requestedExam = parseInt(params.get('exam'), 10);
    if (requestedExam && taskClassroom && taskClassroom.exams.some(function (item) { return Number(item.id) === requestedExam; })) {
        if (loadExamDetail(requestedExam)) {
            activeExamId = requestedExam;
            activeLessonId = null;
            activeMaterialId = null;
        }
    }

    renderAll();
}

function loadClassroom() {
    const result = ELIPS.getMaterialClassroom({ classId: activeClassId });
    if (!result.ok) {
        renderBlocked('Akses Materi', result.message);
        return false;
    }
    classroom = result.data;
    return true;
}

function loadTaskClassroom() {
    taskClassroom = null;
    if (!activeClassId) return false;
    const result = ELIPS.getAssignmentClassroom({ classId: activeClassId });
    if (!result.ok) {
        taskClassroom = null;
        return false;
    }
    taskClassroom = result.data;
    return true;
}

function buildFlatLessonsFromClassroom() {
    flatLessons = (classroom && classroom.lessons ? classroom.lessons : []).map(function (lesson) {
        return {
            lesson: lesson,
            module: { id: lesson.moduleId, title: lesson.moduleTitle }
        };
    });
}

function classroomLesson(lessonId) {
    if (!classroom) return null;
    return classroom.lessons.find(function (item) {
        return Number(item.id) === Number(lessonId);
    }) || null;
}

function classroomMaterial(materialId) {
    if (!classroom) return null;
    return classroom.materials.find(function (item) {
        return Number(item.id) === Number(materialId);
    }) || null;
}

function isLessonCompleted(lessonId) {
    const item = classroomLesson(lessonId);
    if (item) return !!item.completed;
    return ELIPS.isLessonCompleted(activeStudent.id, activeCourse.id, lessonId);
}

function materialUnlocked(materialId) {
    if (canBypassLock) return true;
    const item = classroomMaterial(materialId);
    return !!item && !item.locked;
}

function lessonUnlocked(lessonId) {
    if (canBypassLock) return true;
    const item = classroomLesson(lessonId);
    if (item) return !item.locked;
    return ELIPS.isLessonUnlocked(activeStudent.id, activeCourse.id, lessonId);
}

function renderBlocked(title, message) {
    document.getElementById('learningCourseTitle').textContent = 'Akses Materi';
    document.getElementById('learningProgressText').textContent = 'Progres tidak tersedia';
    document.getElementById('learningProgressFill').style.width = '0%';

    const backPath = activeStudent ? ELIPS.dashboardPathForRole(activeStudent.role) : 'student/dashboard.php';
    const layout = document.getElementById('learningLayout');
    layout.style.display = 'block';
    layout.innerHTML = [
        '<div style="max-width: 640px; margin: 4rem auto; padding: 0 1rem;">',
        '  <div class="learning-article" style="padding: 2.5rem; text-align: center;">',
        '    <i class="bi bi-lock-fill" style="font-size: 3rem; color: var(--warning);"></i>',
        '    <h1 class="learning-article-title" style="margin-top: 1rem; font-size: 1.5rem;">' + ELIPS.escapeHtml(title) + '</h1>',
        '    <p style="color: var(--text-secondary); margin: 1rem 0 1.5rem;">' + ELIPS.escapeHtml(message) + '</p>',
        '    <a href="' + backPath + '" class="btn btn-primary"><i class="bi bi-arrow-left"></i> Kembali ke Dashboard</a>',
        '  </div>',
        '</div>'
    ].join('');
}

function renderAll() {
    if (!activeLessonId && !activeMaterialId && !activeAssignmentId && !activeExamId && classroom && classroom.materials.length > 0) {
        activeMaterialId = Number(classroom.materials[0].id);
    }
    renderSidebar();
    renderProgress();
    if (transcriptMode) renderTranscript();
    else if (activeAssignmentId) renderAssignment();
    else if (activeExamId) renderExam();
    else if (activeMaterialId) renderMaterial(activeMaterialId);
    else renderLesson(activeLessonId);
}

function renderProgress() {
    if (isPreviewMode) {
        const materialCount = classroom ? classroom.materials.length : 0;
        document.getElementById('learningProgressText').textContent =
            'Mode Pratinjau • ' + flatLessons.length + ' Pelajaran' +
            (materialCount > 0 ? ' • ' + materialCount + ' Materi Tambahan' : '');
        document.getElementById('learningProgressFill').style.width = '0%';
        return;
    }

    if (classroom) {
        const stats = classroom.stats || {};
        const total = Number(stats.lessonTotal) || 0;
        const completed = Number(stats.lessonCompleted) || 0;
        const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
        let text = 'Progres: ' + completed + '/' + total + ' Pelajaran (' + percentage + '%)';
        if (Number(stats.materialTotal) > 0) {
            text += ' • Materi Tambahan: ' + (Number(stats.materialCompleted) || 0) + '/' + Number(stats.materialTotal);
        }
        document.getElementById('learningProgressText').textContent = text;
        document.getElementById('learningProgressFill').style.width = percentage + '%';
        return;
    }

    const progress = ELIPS.getCourseProgress(activeStudent.id, activeCourse.id);
    document.getElementById('learningProgressText').textContent =
        'Progres: ' + progress.completed + '/' + progress.total + ' Pelajaran (' + progress.percentage + '%)';
    document.getElementById('learningProgressFill').style.width = progress.percentage + '%';
}

function typeLabel(type) {
    return type === 'video' ? 'Video'
        : type === 'link' ? 'Link'
        : type === 'file' ? 'File'
        : type === 'document' ? 'Dokumen'
        : 'Teks';
}

function lessonProgressIcon(completed, unlocked) {
    return completed ? 'bi-check-circle-fill lesson-completed' : (unlocked ? 'bi-circle' : 'bi-lock-fill');
}

function lessonSidebarHtml(lesson) {
    const completed = !!lesson.completed;
    const unlocked = canBypassLock || !lesson.locked;
    const isActive = !activeMaterialId && Number(lesson.id) === Number(activeLessonId);
    const reason = lesson.reason || '';
    return '<a href="#" class="learning-lesson ' + (isActive ? 'active ' : '') + (unlocked ? '' : 'locked') + '"' +
        (reason ? ' title="' + ELIPS.escapeHtml(reason) + '"' : '') +
        ' onclick="selectLesson(' + lesson.id + ', event)">' +
        '<div class="learning-lesson-left">' +
        '<i class="bi ' + lessonProgressIcon(completed, unlocked) + '"></i>' +
        '<span class="learning-lesson-title">' + ELIPS.escapeHtml(lesson.title) + '</span>' +
        '</div>' +
        '<span class="learning-lesson-type">' + typeLabel(lesson.type) + '</span>' +
        '</a>';
}

function materialSidebarHtml(item) {
    const completed = !!item.completed;
    const unlocked = canBypassLock || !item.locked;
    const isActive = Number(item.id) === Number(activeMaterialId);
    const reason = item.reason || '';
    return '<a href="#" class="learning-lesson ' + (isActive ? 'active ' : '') + (unlocked ? '' : 'locked') + '"' +
        (reason ? ' title="' + ELIPS.escapeHtml(reason) + '"' : '') +
        ' onclick="selectMaterial(' + item.id + ', event)">' +
        '<div class="learning-lesson-left">' +
        '<i class="bi ' + lessonProgressIcon(completed, unlocked) + '"></i>' +
        '<span class="learning-lesson-title">' + ELIPS.escapeHtml(item.title) + '</span>' +
        '</div>' +
        '<span class="learning-lesson-type">' + typeLabel(item.type) + '</span>' +
        '</a>';
}

function appendSidebarModule(container, title, itemsHtml, isOpen) {
    const moduleEl = document.createElement('div');
    moduleEl.className = 'learning-module';
    moduleEl.innerHTML =
        '<div class="learning-module-header">' +
        '<span class="learning-module-name">' + ELIPS.escapeHtml(title) + '</span>' +
        '<i class="bi bi-chevron-down"></i>' +
        '</div>' +
        '<div class="learning-lesson-list" style="display: ' + (isOpen ? 'flex' : 'none') + ';">' + itemsHtml + '</div>';

    const header = moduleEl.querySelector('.learning-module-header');
    header.addEventListener('click', function () {
        const list = header.nextElementSibling;
        list.style.display = list.style.display === 'none' ? 'flex' : 'none';
    });
    container.appendChild(moduleEl);
}

function renderSidebar() {
    const container = document.getElementById('learningModules');
    container.innerHTML = '';

    if (classroom) {
        const modules = [];
        const moduleMap = {};
        classroom.lessons.forEach(function (lesson) {
            const moduleId = Number(lesson.moduleId);
            if (!moduleMap[moduleId]) {
                moduleMap[moduleId] = {
                    id: moduleId,
                    title: lesson.moduleTitle || 'Modul',
                    order: Number(lesson.moduleOrder) || 0,
                    lessons: []
                };
                modules.push(moduleMap[moduleId]);
            }
            moduleMap[moduleId].lessons.push(lesson);
        });

        const activeEntry = flatLessons.find(function (entry) { return entry.lesson.id === activeLessonId; });
        const activeModuleId = activeEntry ? Number(activeEntry.module.id) : null;

        modules.forEach(function (item, moduleIndex) {
            const isOpen = activeModuleId
                ? Number(item.id) === activeModuleId
                : (!activeMaterialId && moduleIndex === 0);
            appendSidebarModule(container, item.title, item.lessons.map(lessonSidebarHtml).join(''), isOpen);
        });

        if (classroom.materials.length > 0) {
            appendSidebarModule(
                container,
                'Materi Tambahan Kelas',
                classroom.materials.map(materialSidebarHtml).join(''),
                !!activeMaterialId
            );
        }

        if (taskClassroom && (taskClassroom.assignments.length > 0 || taskClassroom.exams.length > 0)) {
            appendSidebarModule(
                container,
                'Tugas & Ujian',
                renderTaskSidebarItems(),
                !!activeAssignmentId || !!activeExamId
            );
        }
        if (activeEnrollment) {
            appendSidebarModule(container, 'Hasil Belajar', transcriptSidebarHtml(), transcriptMode);
        }
        return;
    }

    const structure = ELIPS.getCourseStructure(activeCourse.id);
    const activeEntry = flatLessons.find(function (entry) { return entry.lesson.id === activeLessonId; });
    const activeModuleId = activeEntry ? activeEntry.module.id : null;

    structure.forEach(function (item, moduleIndex) {
        const lessons = item.lessons.map(function (lesson) {
            return {
                id: lesson.id,
                title: lesson.title,
                type: lesson.type,
                completed: ELIPS.isLessonCompleted(activeStudent.id, activeCourse.id, lesson.id),
                locked: !lessonUnlocked(lesson.id),
                reason: ''
            };
        });
        const isModuleOpen = activeModuleId ? item.module.id === activeModuleId : moduleIndex === 0;
        appendSidebarModule(container, item.module.title, lessons.map(lessonSidebarHtml).join(''), isModuleOpen);
    });
    if (activeEnrollment) {
        appendSidebarModule(container, 'Hasil Belajar', transcriptSidebarHtml(), transcriptMode);
    }
}

function transcriptSidebarHtml() {
    return '<a href="#" class="learning-lesson ' + (transcriptMode ? 'active ' : '') + '" onclick="selectTranscript(event)">' +
        '<div class="learning-lesson-left">' +
        '<i class="bi bi-award"></i>' +
        '<span class="learning-lesson-title">Nilai &amp; Transkrip</span>' +
        '</div>' +
        '<span class="learning-lesson-type">Nilai</span>' +
        '</a>';
}

function selectTranscript(event) {
    if (event) event.preventDefault();
    transcriptMode = true;
    activeLessonId = null;
    activeMaterialId = null;
    activeAssignmentId = null;
    activeExamId = null;
    renderAll();
    const main = document.querySelector('.learning-main');
    if (main) main.scrollTop = 0;
}

function selectLesson(lessonId, event) {
    if (event) event.preventDefault();
    const entry = flatLessons.find(function (e) { return e.lesson.id === lessonId; });
    if (!entry) return;

    if (!lessonUnlocked(lessonId)) {
        const item = classroomLesson(lessonId);
        ELIPS.toast(item && item.reason ? item.reason : 'Selesaikan prasyaratnya terlebih dahulu untuk membuka materi ini.');
        return;
    }

    activeLessonId = lessonId;
    activeMaterialId = null;
    transcriptMode = false;
    renderAll();
    const main = document.querySelector('.learning-main');
    if (main) main.scrollTop = 0;
}

function selectMaterial(materialId, event) {
    if (event) event.preventDefault();
    const item = classroomMaterial(materialId);
    if (!item) return;
    if (!canBypassLock && item.locked) {
        ELIPS.toast(item.reason || 'Materi tambahan ini masih terkunci.');
        return;
    }
    activeMaterialId = Number(materialId);
    activeLessonId = null;
    activeAssignmentId = null;
    activeExamId = null;
    transcriptMode = false;
    renderAll();
    const main = document.querySelector('.learning-main');
    if (main) main.scrollTop = 0;
}

// ---------- Tugas & ujian (Phase 5) ----------
function taskFormatDateTime(value) {
    if (!value) return '-';
    const date = new Date(value);
    if (isNaN(date.getTime())) return ELIPS.escapeHtml(String(value));
    return date.toLocaleString('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function taskFormatDate(value) {
    if (!value) return '-';
    const date = new Date(value);
    if (isNaN(date.getTime())) return ELIPS.escapeHtml(String(value));
    return date.toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
}

function taskFileSize(size) {
    const value = Number(size);
    if (!value || value < 0) return '';
    if (value >= 1048576) return (value / 1048576).toFixed(1) + ' MB';
    if (value >= 1024) return Math.round(value / 1024) + ' KB';
    return value + ' B';
}

function taskStatusBadge(status) {
    const map = { draft: 'badge-warning', published: 'badge-success', closed: 'badge-primary', archived: 'badge' };
    return '<span class="badge ' + (map[status] || 'badge') + '">' + ELIPS.escapeHtml(TASK_STATUS_LABELS[status] || status) + '</span>';
}

function taskSubmissionBadge(status) {
    const map = {
        submitted: 'badge-primary', late: 'badge-warning', reviewed: 'badge-success',
        revision_requested: 'badge-warning', resubmitted: 'badge-primary', accepted: 'badge-success'
    };
    return '<span class="badge ' + (map[status] || 'badge') + '">' + ELIPS.escapeHtml(TASK_SUBMISSION_LABELS[status] || status) + '</span>';
}

function renderTaskSidebarItems() {
    const items = [];
    taskClassroom.assignments.forEach(function (item) {
        const submission = item.submission;
        const done = submission && ['reviewed', 'accepted'].indexOf(submission.status) !== -1;
        const isActive = Number(item.id) === Number(activeAssignmentId);
        items.push('<a href="#" class="learning-lesson ' + (isActive ? 'active ' : '') + '" onclick="selectAssignment(' + item.id + ', event)">' +
            '<div class="learning-lesson-left">' +
            '<i class="bi ' + (done ? 'bi-check-circle-fill lesson-completed' : 'bi-clipboard') + '"></i>' +
            '<span class="learning-lesson-title">' + ELIPS.escapeHtml(item.title) + '</span>' +
            '</div>' +
            '<span class="learning-lesson-type">Tugas</span>' +
            '</a>');
    });
    taskClassroom.exams.forEach(function (item) {
        const result = item.result;
        const done = result && result.status === 'graded';
        const isActive = Number(item.id) === Number(activeExamId);
        items.push('<a href="#" class="learning-lesson ' + (isActive ? 'active ' : '') + '" onclick="selectExam(' + item.id + ', event)">' +
            '<div class="learning-lesson-left">' +
            '<i class="bi ' + (done ? 'bi-check-circle-fill lesson-completed' : 'bi-journal-check') + '"></i>' +
            '<span class="learning-lesson-title">' + ELIPS.escapeHtml(item.title) + '</span>' +
            '</div>' +
            '<span class="learning-lesson-type">Ujian</span>' +
            '</a>');
    });
    return items.join('');
}

function loadAssignmentDetail(assignmentId) {
    const result = ELIPS.getAssignmentDetail({ id: assignmentId });
    if (!result.ok) {
        ELIPS.toast(result.message);
        return false;
    }
    assignmentDetail = result.data;
    return true;
}

function loadExamDetail(examId) {
    const result = ELIPS.getExamDetail({ id: examId });
    if (!result.ok) {
        ELIPS.toast(result.message);
        return false;
    }
    examDetail = result.data;
    return true;
}

function selectAssignment(assignmentId, event) {
    if (event) event.preventDefault();
    if (!loadAssignmentDetail(assignmentId)) return;
    activeAssignmentId = Number(assignmentId);
    activeExamId = null;
    activeLessonId = null;
    activeMaterialId = null;
    pendingSubmissionFiles = [];
    transcriptMode = false;
    renderAll();
    const main = document.querySelector('.learning-main');
    if (main) main.scrollTop = 0;
}

function selectExam(examId, event) {
    if (event) event.preventDefault();
    if (!loadExamDetail(examId)) return;
    activeExamId = Number(examId);
    activeAssignmentId = null;
    activeLessonId = null;
    activeMaterialId = null;
    transcriptMode = false;
    renderAll();
    const main = document.querySelector('.learning-main');
    if (main) main.scrollTop = 0;
}

function taskClassroomItem(kind, id) {
    if (!taskClassroom) return null;
    const list = kind === 'exam' ? taskClassroom.exams : taskClassroom.assignments;
    return list.find(function (item) { return Number(item.id) === Number(id); }) || null;
}

function gradeComponentStatusBadge(status) {
    const map = {
        graded: { label: 'Dinilai', className: 'badge-success' },
        not_assessed: { label: 'Belum Dinilai', className: 'badge-primary' },
        missing: { label: 'Belum Ada Nilai', className: 'badge-danger' },
        excused: { label: 'Dikecualikan', className: 'badge-warning' }
    };
    const item = map[status] || { label: status || '-', className: 'badge-primary' };
    return '<span class="badge ' + item.className + '">' + ELIPS.escapeHtml(item.label) + '</span>';
}

function gradeScoreText(value) {
    if (value === null || value === undefined || value === '') return '-';
    const number = Number(value);
    if (isNaN(number)) return '-';
    return String(Math.round(number * 100) / 100);
}

function renderTranscript() {
    const container = document.getElementById('learningContent');
    if (!activeEnrollment) {
        container.innerHTML = '<p style="color: var(--text-secondary);">Transkrip nilai tersedia setelah Anda terdaftar pada kursus.</p>';
        return;
    }

    const result = ELIPS.gradeTranscript({
        enrollmentId: activeEnrollment.id,
        actorId: activeStudent.id
    });
    if (!result || !result.ok) {
        container.innerHTML = '<p style="color: var(--danger);">' +
            ELIPS.escapeHtml(result && result.message ? result.message : 'Transkrip nilai belum tersedia.') + '</p>';
        return;
    }

    const data = result.data || {};
    const computed = data.computed || {};
    const grade = data.grade || null;
    const finalized = !!(grade && grade.status === 'finalized');
    const components = computed.components || [];
    const corrections = data.corrections || [];
    const hasScheme = computed.status !== 'no_scheme' && components.length > 0;

    const statusNote = !hasScheme
        ? '<div class="form-hint" style="margin-bottom:1rem;">Skema penilaian kelas belum disiapkan instruktur.</div>'
        : (!finalized
            ? '<div class="form-hint" style="margin-bottom:1rem;"><i class="bi bi-info-circle"></i> Nilai masih berjalan. Nilai akhir akan dikunci setelah instruktur memfinalisasi.</div>'
            : '<div class="form-hint" style="margin-bottom:1rem;"><i class="bi bi-lock-fill"></i> Nilai sudah difinalisasi pada ' +
                ELIPS.escapeHtml(taskFormatDateTime(grade.finalizedAt)) + '. Perubahan hanya melalui koreksi yang tercatat.</div>');

    const summary = [
        '<div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:0.75rem; margin-bottom:1.25rem;">',
        '<div class="learning-article" style="padding:1rem;">',
        '  <div style="font-size:0.8125rem; color:var(--text-secondary);">Nilai Akhir</div>',
        '  <div style="font-size:1.75rem; font-weight:700;">' + gradeScoreText(computed.finalScore) + '</div>',
        '  <div class="form-hint">Predikat: <strong>' + ELIPS.escapeHtml(computed.letter || '-') + '</strong></div>',
        '</div>',
        '<div class="learning-article" style="padding:1rem;">',
        '  <div style="font-size:0.8125rem; color:var(--text-secondary);">Status</div>',
        '  <div style="margin-top:0.35rem;">' + (finalized
            ? '<span class="badge badge-success">Final</span>'
            : '<span class="badge badge-warning">' + ELIPS.escapeHtml(computed.status === 'incomplete' ? 'Belum Lengkap' : 'Berjalan') + '</span>') + '</div>',
        '  <div class="form-hint" style="margin-top:0.35rem;">' + (computed.passed === null || computed.passed === undefined
            ? 'Kriteria kelulusan belum dapat ditentukan'
            : (computed.passed ? 'Memenuhi batas lulus ' : 'Di bawah batas lulus ') + gradeScoreText(computed.passScore)) + '</div>',
        '</div>',
        '<div class="learning-article" style="padding:1rem;">',
        '  <div style="font-size:0.8125rem; color:var(--text-secondary);">Skema</div>',
        '  <div style="font-weight:600; margin-top:0.35rem;">' + ELIPS.escapeHtml(computed.schemeName || '-') + '</div>',
        '  <div class="form-hint">Pembulatan: ' + ELIPS.escapeHtml(computed.rounding || '-') + '</div>',
        '</div>',
        '</div>'
    ].join('');

    const missing = (computed.missing || []).length
        ? '<div class="form-hint" style="color:var(--danger); margin-bottom:1rem;"><i class="bi bi-exclamation-triangle"></i> Komponen wajib belum lengkap: ' +
            ELIPS.escapeHtml(computed.missing.join(', ')) + '</div>'
        : '';

    const componentRows = components.map(function (component) {
        const activities = (component.activities || []).map(function (activity) {
            return '<li>' + ELIPS.escapeHtml(activity.title || 'Aktivitas') +
                ' — ' + gradeScoreText(activity.normalized) +
                ' <span class="form-hint">(' + ELIPS.escapeHtml(activity.status || '-') + ')</span></li>';
        }).join('');
        return [
            '<tr>',
            '<td><div class="table-course-title">' + ELIPS.escapeHtml(component.name) + '</div>' +
                '<div class="table-course-meta">' + ELIPS.escapeHtml(component.type) + ' • bobot ' + gradeScoreText(component.weight) + '%</div>' +
                (activities ? '<ul style="margin:0.35rem 0 0 1rem; font-size:0.8125rem;">' + activities + '</ul>' : '') + '</td>',
            '<td>' + gradeScoreText(component.score) + '</td>',
            '<td>' + gradeComponentStatusBadge(component.status) + '</td>',
            '<td>' + (component.isRequired === false ? 'Tidak wajib' : 'Wajib') + '</td>',
            '</tr>'
        ].join('');
    }).join('');

    const componentTable = hasScheme
        ? '<div style="overflow-x:auto;"><table class="dashboard-table"><thead><tr><th>Komponen</th><th>Nilai</th><th>Status</th><th>Kewajiban</th></tr></thead><tbody>' +
            componentRows + '</tbody></table></div>'
        : '';

    const correctionTable = corrections.length
        ? '<h3 style="font-size:1rem; margin:1.5rem 0 0.5rem;">Riwayat Koreksi Nilai</h3>' +
            '<div style="overflow-x:auto;"><table class="dashboard-table"><thead><tr><th>Waktu</th><th>Perubahan</th><th>Alasan</th><th>Oleh</th></tr></thead><tbody>' +
            corrections.map(function (correction) {
                return '<tr>' +
                    '<td>' + ELIPS.escapeHtml(taskFormatDateTime(correction.createdAt)) + '</td>' +
                    '<td>' + gradeScoreText(correction.previousScore) + ' (' + ELIPS.escapeHtml(correction.previousLetter || '-') + ') → ' +
                        gradeScoreText(correction.newScore) + ' (' + ELIPS.escapeHtml(correction.newLetter || '-') + ')</td>' +
                    '<td>' + ELIPS.escapeHtml(correction.reason || '-') + '</td>' +
                    '<td>' + ELIPS.escapeHtml(correction.actorName || '-') + '</td>' +
                    '</tr>';
            }).join('') + '</tbody></table></div>'
        : '';

    container.innerHTML = [
        '<div class="learning-article" style="padding:1.5rem;">',
        '  <h1 class="learning-article-title" style="font-size:1.5rem; margin-bottom:0.5rem;">Nilai &amp; Transkrip</h1>',
        '  <p style="color:var(--text-secondary); margin-bottom:1rem;">' + ELIPS.escapeHtml(activeCourse ? activeCourse.title : '') + '</p>',
        statusNote,
        summary,
        missing,
        componentTable,
        correctionTable,
        '</div>'
    ].join('');
}

function renderAssignment() {
    const container = document.getElementById('learningContent');
    const item = assignmentDetail;
    if (!item) {
        container.innerHTML = '<p style="color: var(--text-secondary);">Tugas tidak ditemukan.</p>';
        return;
    }
    const classroomItem = taskClassroomItem('assignment', item.id);
    const dueText = item.dueAt ? 'Tenggat ' + taskFormatDateTime(item.dueAt) : 'Tanpa tenggat';
    const openText = item.openAt ? 'Dibuka ' + taskFormatDateTime(item.openAt) : 'Langsung tersedia';
    const relation = item.moduleTitle
        ? item.moduleTitle + (item.lessonTitle ? ' • ' + item.lessonTitle : '')
        : 'Tugas kelas';

    const files = (item.files || []).map(function (file) {
        const label = ELIPS.escapeHtml(file.fileName) + (file.fileSize ? ' (' + taskFileSize(file.fileSize) + ')' : '');
        return '<li>' + (file.filePath
            ? '<a href="' + ELIPS.escapeHtml(file.filePath) + '" target="_blank" rel="noopener">' + label + '</a>'
            : label) + '</li>';
    }).join('');

    const rubrics = (item.rubrics || []).length > 0
        ? '<div style="margin-top: 1.25rem;"><h3 style="font-size: 1rem; margin-bottom: 0.5rem;">Rubrik Penilaian</h3>' +
            '<div style="overflow-x: auto;"><table class="dashboard-table"><thead><tr><th>Kriteria</th><th>Deskripsi</th><th>Nilai Maks</th></tr></thead><tbody>' +
            item.rubrics.map(function (rubric) {
                return '<tr><td>' + ELIPS.escapeHtml(rubric.criterion) + '</td><td>' + ELIPS.escapeHtml(rubric.description || '-') +
                    '</td><td>' + (Number(rubric.maxScore) || 0) + '</td></tr>';
            }).join('') + '</tbody></table></div></div>'
        : '';

    container.innerHTML =
        '<article class="learning-article">' +
        '<header class="learning-article-header">' +
        '<div class="learning-article-meta"><span class="learning-article-breadcrumb">' + ELIPS.escapeHtml(relation) + '</span></div>' +
        '<h1 class="learning-article-title">' + ELIPS.escapeHtml(item.title) + '</h1>' +
        '<div style="display: flex; gap: 0.5rem; flex-wrap: wrap; margin-top: 0.75rem;">' +
        '<span class="badge badge-primary">' + ELIPS.escapeHtml(TASK_ASSIGNMENT_TYPE_LABELS[item.type] || item.type) + '</span>' +
        taskStatusBadge(item.status) +
        '<span class="badge">Nilai Maks ' + (Number(item.maxScore) || 0) + '</span>' +
        '<span class="badge">Bobot ' + (Number(item.weight) || 0) + '%</span>' +
        '</div>' +
        '</header>' +
        '<div class="learning-article-body">' +
        '<div style="display: flex; gap: 1rem; flex-wrap: wrap; color: var(--text-secondary); font-size: 0.875rem; margin-bottom: 1rem;">' +
        '<span><i class="bi bi-calendar-event"></i> ' + ELIPS.escapeHtml(openText) + '</span>' +
        '<span><i class="bi bi-alarm"></i> ' + ELIPS.escapeHtml(dueText) + '</span>' +
        '</div>' +
        (item.instructions ? '<div style="white-space: pre-wrap;">' + ELIPS.escapeHtml(item.instructions) + '</div>' : '<p>Tidak ada instruksi khusus.</p>') +
        (files ? '<div style="margin-top: 1.25rem;"><h3 style="font-size: 1rem; margin-bottom: 0.5rem;">Lampiran</h3><ul style="margin-left: 1.25rem;">' + files + '</ul></div>' : '') +
        rubrics +
        renderSubmissionPanel(item, classroomItem) +
        '</div>' +
        '<div class="learning-actions">' +
        '<div class="learning-nav">' +
        (flatLessons.length > 0 ? '<button class="btn btn-ghost" onclick="selectLesson(' + flatLessons[0].lesson.id + ', event)"><i class="bi bi-arrow-left"></i> Kembali ke Pelajaran</button>' : '') +
        '</div>' +
        '</div>' +
        '</article>';
}

function renderSubmissionPanel(item, classroomItem) {
    if (isPreviewMode) {
        return '<div style="padding: 1rem; background: #eff6ff; color: #1e40af; border-radius: var(--radius); margin-top: 1.5rem;">' +
            '<i class="bi bi-eye"></i> Mode pratinjau: pengumpulan tugas dilakukan oleh peserta.</div>';
    }

    const submission = item.submission;
    if (!submission) {
        if (item.type === 'in_class_practice') {
            return '<div style="padding: 1rem; background: #eff6ff; color: #1e40af; border-radius: var(--radius); margin-top: 1.5rem;">' +
                '<i class="bi bi-info-circle"></i> Tugas praktik kelas dicatat langsung oleh instruktur.</div>';
        }
        if (classroomItem && classroomItem.canSubmit) {
            return renderSubmissionForm(item, false);
        }
        return '<div style="padding: 1rem; background: #fef3c7; color: #92400e; border-radius: var(--radius); margin-top: 1.5rem;">' +
            '<i class="bi bi-lock"></i> Tugas ini belum dibuka atau sudah ditutup untuk pengumpulan.</div>';
    }

    const files = (submission.files || []).map(function (file) {
        const label = ELIPS.escapeHtml(file.fileName) + (file.fileSize ? ' (' + taskFileSize(file.fileSize) + ')' : '');
        return '<li>' + (file.filePath
            ? '<a href="' + ELIPS.escapeHtml(file.filePath) + '" target="_blank" rel="noopener">' + label + '</a>'
            : label) + '</li>';
    }).join('');
    const reviews = (submission.reviews || []).map(function (review) {
        return '<li><strong>' + ELIPS.escapeHtml(review.action) + '</strong>' +
            (review.score !== null && review.score !== undefined ? ' • nilai ' + review.score : '') +
            (review.note ? ' — ' + ELIPS.escapeHtml(review.note) : '') +
            ' <span style="color: var(--text-secondary);">(' + taskFormatDateTime(review.createdAt) + ')</span></li>';
    }).join('');

    const canResubmit = submission.status === 'revision_requested' && classroomItem && classroomItem.canSubmit;
    return [
        '<div style="padding: 1rem; border: 1px solid var(--border); border-radius: var(--radius); margin-top: 1.5rem;">',
        '  <div style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 0.75rem;">',
        '    <h3 style="font-size: 1rem; margin: 0;">Pengumpulan Anda</h3>',
        taskSubmissionBadge(submission.status),
        '  </div>',
        '  <div style="display: flex; gap: 1rem; flex-wrap: wrap; font-size: 0.875rem; color: var(--text-secondary); margin-bottom: 0.75rem;">',
        '    <span><i class="bi bi-send"></i> ' + taskFormatDateTime(submission.submittedAt) + '</span>',
        submission.isLate ? '    <span style="color: var(--warning);"><i class="bi bi-exclamation-triangle"></i> Terlambat</span>' : '',
        '    <span><i class="bi bi-star"></i> Nilai: ' + (submission.score !== null && submission.score !== undefined ? submission.score + ' / ' + (Number(item.maxScore) || 0) : 'Belum dinilai') + '</span>',
        '  </div>',
        submission.textAnswer
            ? '  <div style="white-space: pre-wrap; background: var(--background); padding: 0.75rem; border-radius: var(--radius); font-size: 0.875rem; margin-bottom: 0.75rem;">' + ELIPS.escapeHtml(submission.textAnswer) + '</div>'
            : '',
        files ? '  <div style="font-size: 0.875rem; margin-bottom: 0.75rem;"><strong>File terkumpul:</strong><ul style="margin: 0.25rem 0 0 1rem;">' + files + '</ul></div>' : '',
        submission.feedback
            ? '  <div style="font-size: 0.875rem; margin-bottom: 0.75rem;"><strong>Umpan balik instruktur:</strong> ' + ELIPS.escapeHtml(submission.feedback) + '</div>'
            : '',
        reviews ? '  <div style="font-size: 0.875rem;"><strong>Riwayat:</strong><ul style="margin: 0.25rem 0 0 1rem;">' + reviews + '</ul></div>' : '',
        '</div>',
        canResubmit
            ? renderSubmissionForm(item, true)
            : (submission.status === 'revision_requested'
                ? '<div style="padding: 1rem; background: #fef3c7; color: #92400e; border-radius: var(--radius); margin-top: 1rem;"><i class="bi bi-lock"></i> Revisi diminta, tetapi tugas sudah ditutup. Hubungi instruktur.</div>'
                : '')
    ].join('');
}

function renderSubmissionForm(item, isResubmission) {
    const requireFile = !!item.requireFile || item.type === 'file_upload';
    return [
        '<div style="padding: 1rem; border: 1px solid var(--border); border-radius: var(--radius); margin-top: 1.5rem;">',
        '  <h3 style="font-size: 1rem; margin: 0 0 0.75rem;">' + (isResubmission ? 'Kumpulkan Ulang Tugas' : 'Kumpulkan Tugas') + '</h3>',
        '  <div class="form-group">',
        '    <label class="form-label" for="submissionTextAnswer">Jawaban Teks' + (item.type === 'text_submission' ? ' *' : '') + '</label>',
        '    <textarea id="submissionTextAnswer" class="form-input" rows="5" placeholder="Tulis jawaban atau catatan pengumpulan..."></textarea>',
        '  </div>',
        '  <div class="form-group">',
        '    <label class="form-label" for="submissionFileInput">Lampiran File' + (requireFile ? ' *' : '') + '</label>',
        '    <input type="file" id="submissionFileInput" class="form-input" multiple onchange="addSubmissionFiles(this)">',
        '    <small class="form-hint">' + (item.allowedTypes ? 'Tipe diizinkan: ' + ELIPS.escapeHtml(item.allowedTypes) + '. ' : '') +
            (item.maxFileSize ? 'Maksimum ' + taskFileSize(item.maxFileSize) + ' per file.' : '') + '</small>',
        '  </div>',
        '  <div id="submissionFileList" style="font-size: 0.875rem; margin-bottom: 0.75rem;"></div>',
        '  <button class="btn btn-primary" onclick="submitAssignmentForm(' + item.id + ')"><i class="bi bi-send"></i> ' +
            (isResubmission ? 'Kumpulkan Ulang' : 'Kumpulkan Tugas') + '</button>',
        '</div>'
    ].join('');
}

function renderPendingSubmissionFiles() {
    const list = document.getElementById('submissionFileList');
    if (!list) return;
    if (pendingSubmissionFiles.length === 0) {
        list.innerHTML = '';
        return;
    }
    list.innerHTML = '<strong>File dipilih:</strong><ul style="margin: 0.25rem 0 0 1rem;">' +
        pendingSubmissionFiles.map(function (file, index) {
            return '<li>' + ELIPS.escapeHtml(file.fileName) + (file.fileSize ? ' (' + taskFileSize(file.fileSize) + ')' : '') +
                ' <button type="button" class="btn btn-ghost" style="padding: 0 0.25rem; font-size: 0.75rem; color: var(--danger);" onclick="removeSubmissionFile(' + index + ')"><i class="bi bi-x"></i></button></li>';
        }).join('') + '</ul>';
}

function addSubmissionFiles(input) {
    const files = input.files ? Array.prototype.slice.call(input.files) : [];
    files.forEach(function (file) {
        pendingSubmissionFiles.push({
            fileName: file.name,
            fileSize: file.size,
            mimeType: file.type || '',
            filePath: ''
        });
    });
    input.value = '';
    renderPendingSubmissionFiles();
}

function removeSubmissionFile(index) {
    pendingSubmissionFiles.splice(index, 1);
    renderPendingSubmissionFiles();
}

function submitAssignmentForm(assignmentId) {
    if (isPreviewMode) {
        ELIPS.toast('Mode pratinjau: pengumpulan tugas dilakukan oleh peserta.');
        return;
    }
    const textField = document.getElementById('submissionTextAnswer');
    const payload = { textAnswer: textField ? textField.value.trim() : '' };
    if (pendingSubmissionFiles.length > 0) payload.files = pendingSubmissionFiles.slice();
    const result = ELIPS.submitAssignment(assignmentId, payload);
    ELIPS.toast(result.message);
    if (!result.ok) return;
    pendingSubmissionFiles = [];
    loadTaskClassroom();
    loadAssignmentDetail(assignmentId);
    renderAll();
}

function renderExam() {
    const container = document.getElementById('learningContent');
    const item = examDetail;
    if (!item) {
        container.innerHTML = '<p style="color: var(--text-secondary);">Ujian tidak ditemukan.</p>';
        return;
    }
    const schedule = item.examDate
        ? taskFormatDate(item.examDate) + (item.startTime ? ' • ' + item.startTime : '')
        : 'Belum dijadwalkan';
    const result = item.result;

    let resultPanel = '';
    if (isPreviewMode) {
        resultPanel = '<div style="padding: 1rem; background: #eff6ff; color: #1e40af; border-radius: var(--radius); margin-top: 1.5rem;">' +
            '<i class="bi bi-eye"></i> Mode pratinjau: hasil ujian milik peserta tidak ditampilkan.</div>';
    } else if (result) {
        const graded = result.status === 'graded';
        resultPanel = [
            '<div style="padding: 1rem; border: 1px solid var(--border); border-radius: var(--radius); margin-top: 1.5rem;">',
            '  <div style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 0.75rem;">',
            '    <h3 style="font-size: 1rem; margin: 0;">Hasil Ujian Anda</h3>',
            '    <span class="badge ' + (graded ? 'badge-success' : 'badge-warning') + '">' + ELIPS.escapeHtml(TASK_RESULT_LABELS[result.status] || result.status) + '</span>',
            '  </div>',
            '  <div style="display: flex; gap: 1rem; flex-wrap: wrap; font-size: 0.875rem;">',
            '    <span><i class="bi bi-star"></i> Nilai: ' + (graded ? result.score + ' / ' + (Number(item.maxScore) || 0) : 'Belum ada nilai') + '</span>',
            result.gradedAt ? '    <span style="color: var(--text-secondary);"><i class="bi bi-clock"></i> Dinilai ' + taskFormatDateTime(result.gradedAt) + '</span>' : '',
            '  </div>',
            result.note ? '  <div style="font-size: 0.875rem; margin-top: 0.5rem;"><strong>Catatan:</strong> ' + ELIPS.escapeHtml(result.note) + '</div>' : '',
            '</div>'
        ].join('');
    } else {
        resultPanel = '<div style="padding: 1rem; background: #eff6ff; color: #1e40af; border-radius: var(--radius); margin-top: 1.5rem;">' +
            '<i class="bi bi-info-circle"></i> Hasil ujian belum tersedia. Instruktur akan mencatat nilai setelah ujian dilaksanakan.</div>';
    }

    container.innerHTML =
        '<article class="learning-article">' +
        '<header class="learning-article-header">' +
        '<div class="learning-article-meta"><span class="learning-article-breadcrumb">Ujian Kelas</span></div>' +
        '<h1 class="learning-article-title">' + ELIPS.escapeHtml(item.title) + '</h1>' +
        '<div style="display: flex; gap: 0.5rem; flex-wrap: wrap; margin-top: 0.75rem;">' +
        '<span class="badge badge-primary">' + ELIPS.escapeHtml(TASK_EXAM_TYPE_LABELS[item.type] || item.type) + '</span>' +
        taskStatusBadge(item.status) +
        '<span class="badge">Nilai Maks ' + (Number(item.maxScore) || 0) + '</span>' +
        '<span class="badge">Bobot ' + (Number(item.weight) || 0) + '%</span>' +
        '</div>' +
        '</header>' +
        '<div class="learning-article-body">' +
        '<div style="display: flex; gap: 1rem; flex-wrap: wrap; color: var(--text-secondary); font-size: 0.875rem; margin-bottom: 1rem;">' +
        '<span><i class="bi bi-calendar-event"></i> ' + ELIPS.escapeHtml(schedule) + '</span>' +
        (item.durationMinutes ? '<span><i class="bi bi-hourglass-split"></i> ' + item.durationMinutes + ' menit</span>' : '') +
        '</div>' +
        (item.description ? '<p style="color: var(--text-secondary); margin-bottom: 1rem;">' + ELIPS.escapeHtml(item.description) + '</p>' : '') +
        (item.instructions ? '<div style="white-space: pre-wrap;">' + ELIPS.escapeHtml(item.instructions) + '</div>' : '<p>Tidak ada instruksi khusus.</p>') +
        resultPanel +
        '</div>' +
        '<div class="learning-actions">' +
        '<div class="learning-nav">' +
        (flatLessons.length > 0 ? '<button class="btn btn-ghost" onclick="selectLesson(' + flatLessons[0].lesson.id + ', event)"><i class="bi bi-arrow-left"></i> Kembali ke Pelajaran</button>' : '') +
        '</div>' +
        '</div>' +
        '</article>';
}

function renderLesson(lessonId) {
    const container = document.getElementById('learningContent');
    const entry = flatLessons.find(function (e) { return e.lesson.id === lessonId; });
    if (!entry) {
        container.innerHTML = '<p style="color: var(--text-secondary);">Materi tidak ditemukan.</p>';
        return;
    }

    const lesson = entry.lesson;
    const classLesson = classroomLesson(lesson.id);
    const content = classLesson ? String(classLesson.content || '') : String(lesson.content || '');
    const completed = classLesson ? !!classLesson.completed : ELIPS.isLessonCompleted(activeStudent.id, activeCourse.id, lesson.id);
    const index = flatLessons.findIndex(function (e) { return e.lesson.id === lesson.id; });
    const prev = index > 0 ? flatLessons[index - 1] : null;
    const next = index < flatLessons.length - 1 ? flatLessons[index + 1] : null;
    const nextUnlocked = next ? lessonUnlocked(next.lesson.id) : false;
    const approvalRequired = !!(!isPreviewMode && classroom && classroom.settings &&
        classroom.settings.requireInstructorApproval);
    let allComplete = false;
    let certificate = null;
    if (classroom) {
        const stats = classroom.stats || {};
        allComplete = Number(stats.lessonTotal) > 0 && Number(stats.lessonCompleted) === Number(stats.lessonTotal);
    } else {
        const allProgress = ELIPS.getCourseProgress(activeStudent.id, activeCourse.id);
        allComplete = allProgress.total > 0 && allProgress.completed === allProgress.total;
    }
    certificate = ELIPS.getCertificate(activeStudent.id, activeCourse.id);

    let media = '';
    if (lesson.type === 'video') {
        const embed = toEmbedUrl(content);
        media = embed
            ? '<div class="learning-video" style="padding: 0; overflow: hidden;"><iframe src="' + ELIPS.escapeHtml(embed) + '" style="width:100%; height:100%; border:0;" allowfullscreen></iframe></div>'
            : '<div class="learning-video"><i class="bi bi-play-circle" style="font-size: 3rem;"></i></div><p style="color: var(--text-secondary);">Video: ' + ELIPS.escapeHtml(content || 'Belum ada URL video') + '</p>';
    } else if (lesson.type === 'link') {
        media = '<p><a href="' + ELIPS.escapeHtml(content || '#') + '" target="_blank" rel="noopener" class="btn btn-outline"><i class="bi bi-box-arrow-up-right"></i> Buka Link Materi</a></p>';
    } else if (lesson.type === 'file') {
        media = '<p><a href="' + ELIPS.escapeHtml(content || '#') + '" target="_blank" rel="noopener" class="btn btn-outline"><i class="bi bi-file-earmark-arrow-down"></i> ' + ELIPS.escapeHtml(content || 'Unduh File') + '</a></p>';
    }

    let completionNotice = '';
    if (isPreviewMode) {
        completionNotice = '<div style="padding: 1rem; background: #eff6ff; color: #1e40af; border-radius: var(--radius); margin-top: 1.5rem;"><i class="bi bi-eye"></i> Mode pratinjau: Anda melihat materi sebagai instruktur. Progres peserta tidak berubah saat Anda membuka pelajaran ini.</div>';
    } else if (approvalRequired && !completed) {
        completionNotice = '<div style="padding: 1rem; background: #fef3c7; color: #92400e; border-radius: var(--radius); margin-top: 1.5rem;"><i class="bi bi-hourglass-split"></i> Kelas ini mewajibkan konfirmasi instruktur. Hubungi instruktur setelah Anda menyelesaikan materi ini.</div>';
    } else if (allComplete) {
        if (certificate && certificate.status === 'publish') {
            completionNotice = '<div style="padding: 1rem; background: #dcfce7; color: #166534; border-radius: var(--radius); margin-top: 1.5rem;"><i class="bi bi-patch-check-fill"></i> Selamat! Seluruh materi selesai dan e-sertifikat Anda sudah terbit. <a href="student/certificates.php">Lihat sertifikat</a>.</div>';
        } else if (certificate && certificate.status === 'draft') {
            completionNotice = '<div style="padding: 1rem; background: #fef3c7; color: #92400e; border-radius: var(--radius); margin-top: 1.5rem;"><i class="bi bi-hourglass-split"></i> Seluruh materi selesai. E-sertifikat Anda sedang menunggu persetujuan Admin.</div>';
        } else {
            completionNotice = '<div style="padding: 1rem; background: #eff6ff; color: #1e40af; border-radius: var(--radius); margin-top: 1.5rem;"><i class="bi bi-info-circle"></i> Seluruh materi selesai. Nilai dan e-sertifikat akan diberikan oleh instruktur.</div>';
        }
    }

    let completionButton = '';
    if (isPreviewMode) {
        completionButton = '<span class="badge badge-primary" style="padding: 0.5rem 0.75rem;"><i class="bi bi-eye"></i> Mode Pratinjau</span>';
    } else if (completed) {
        completionButton = '<button id="markCompleteBtn" class="btn btn-primary" disabled style="background: var(--success);"><i class="bi bi-check-circle-fill"></i> Selesai</button>';
    } else if (approvalRequired) {
        completionButton = '<button class="btn btn-outline" disabled title="Menunggu konfirmasi instruktur"><i class="bi bi-hourglass-split"></i> Menunggu Konfirmasi Instruktur</button>';
    } else {
        completionButton = '<button id="markCompleteBtn" class="btn btn-primary" onclick="markComplete()"><i class="bi bi-check-circle"></i> Tandai Selesai</button>';
    }

    container.innerHTML =
        '<article class="learning-article">' +
        '<header class="learning-article-header">' +
        '<div class="learning-article-meta"><span class="learning-article-breadcrumb">' + ELIPS.escapeHtml(entry.module.title) + ' &bull; Pelajaran ' + (index + 1) + ' dari ' + flatLessons.length + '</span></div>' +
        '<h1 class="learning-article-title">' + ELIPS.escapeHtml(lesson.title) + '</h1>' +
        '</header>' +
        '<div class="learning-article-body">' +
        (content && lesson.type === 'text' ? ELIPS.sanitizeHtml(content) : '<p>Materi ini belum memiliki konten teks. Silakan gunakan media di bawah.</p>') +
        media +
        completionNotice +
        '</div>' +
        '<div class="learning-actions">' +
        '<div class="learning-nav">' +
        (prev ? '<button class="btn btn-ghost" onclick="selectLesson(' + prev.lesson.id + ', event)"><i class="bi bi-arrow-left"></i> Sebelumnya</button>' : '') +
        (next ? '<button class="btn btn-ghost" ' + (nextUnlocked ? '' : 'disabled title="Selesaikan pelajaran ini terlebih dahulu"') + ' onclick="selectLesson(' + next.lesson.id + ', event)">Selanjutnya <i class="bi bi-arrow-right"></i></button>' : '') +
        '</div>' +
        completionButton +
        '</div>' +
        '</article>';
}

function renderMaterial(materialId) {
    const container = document.getElementById('learningContent');
    const item = classroomMaterial(materialId);
    if (!item) {
        container.innerHTML = '<p style="color: var(--text-secondary);">Materi tambahan tidak ditemukan.</p>';
        return;
    }

    const completed = !!item.completed;
    const content = String(item.content || '');
    const approvalRequired = !!(!isPreviewMode && classroom && classroom.settings &&
        classroom.settings.requireInstructorApproval);

    let body = '';
    if (item.type === 'text') {
        body = content ? ELIPS.sanitizeHtml(content) : '<p>Materi ini belum memiliki konten teks.</p>';
    } else if (item.type === 'video') {
        const embed = toEmbedUrl(content);
        body = embed
            ? '<div class="learning-video" style="padding: 0; overflow: hidden;"><iframe src="' + ELIPS.escapeHtml(embed) + '" style="width:100%; height:100%; border:0;" allowfullscreen></iframe></div>'
            : (content ? '<p><a href="' + ELIPS.escapeHtml(content) + '" target="_blank" rel="noopener" class="btn btn-outline"><i class="bi bi-play-circle"></i> Buka Video</a></p>' : '<p>Belum ada URL video.</p>');
    } else if (item.type === 'link') {
        body = content
            ? '<p><a href="' + ELIPS.escapeHtml(content) + '" target="_blank" rel="noopener" class="btn btn-outline"><i class="bi bi-box-arrow-up-right"></i> Buka Link Materi</a></p>'
            : '<p>Belum ada URL materi.</p>';
    } else {
        const label = item.fileName || content || 'Unduh File';
        const meta = [];
        if (item.fileName) meta.push(item.fileName);
        if (item.fileSize !== null && item.fileSize !== undefined) meta.push(item.fileSize + ' byte');
        if (item.mimeType) meta.push(item.mimeType);
        body = content
            ? '<p><a href="' + ELIPS.escapeHtml(content) + '" target="_blank" rel="noopener" class="btn btn-outline"><i class="bi bi-file-earmark-arrow-down"></i> ' + ELIPS.escapeHtml(label) + '</a></p>'
            : '<p style="color: var(--text-secondary);">File materi belum tersedia untuk diunduh.</p>';
        if (meta.length > 0) {
            body += '<p style="font-size: 0.8125rem; color: var(--text-secondary);">' + ELIPS.escapeHtml(meta.join(' • ')) + '</p>';
        }
    }

    let completionNotice = '';
    if (isPreviewMode) {
        completionNotice = '<div style="padding: 1rem; background: #eff6ff; color: #1e40af; border-radius: var(--radius); margin-top: 1.5rem;"><i class="bi bi-eye"></i> Mode pratinjau: materi tambahan kelas ditampilkan tanpa mengubah progres peserta.</div>';
    } else if (approvalRequired && !completed) {
        completionNotice = '<div style="padding: 1rem; background: #fef3c7; color: #92400e; border-radius: var(--radius); margin-top: 1.5rem;"><i class="bi bi-hourglass-split"></i> Penyelesaian materi ini perlu dikonfirmasi instruktur.</div>';
    }

    let completionButton = '';
    if (isPreviewMode) {
        completionButton = '<span class="badge badge-primary" style="padding: 0.5rem 0.75rem;"><i class="bi bi-eye"></i> Mode Pratinjau</span>';
    } else if (completed) {
        completionButton = '<button class="btn btn-primary" disabled style="background: var(--success);"><i class="bi bi-check-circle-fill"></i> Selesai</button>';
    } else if (approvalRequired) {
        completionButton = '<button class="btn btn-outline" disabled title="Menunggu konfirmasi instruktur"><i class="bi bi-hourglass-split"></i> Menunggu Konfirmasi Instruktur</button>';
    } else {
        completionButton = '<button class="btn btn-primary" onclick="markMaterialComplete()"><i class="bi bi-check-circle"></i> Tandai Selesai</button>';
    }

    const accessLabel = item.accessLevel === 'required' ? 'Wajib'
        : item.accessLevel === 'reference' ? 'Referensi' : 'Opsional';
    const relation = item.lessonTitle ? 'Terkait pelajaran: ' + item.lessonTitle
        : (item.sessionTitle ? 'Terkait sesi: ' + item.sessionTitle : 'Materi tambahan kelas');

    container.innerHTML =
        '<article class="learning-article">' +
        '<header class="learning-article-header">' +
        '<div class="learning-article-meta"><span class="learning-article-breadcrumb">' + ELIPS.escapeHtml(relation) + '</span></div>' +
        '<h1 class="learning-article-title">' + ELIPS.escapeHtml(item.title) + '</h1>' +
        '<div style="display: flex; gap: 0.5rem; flex-wrap: wrap; margin-top: 0.75rem;">' +
        '<span class="badge badge-primary">' + typeLabel(item.type) + '</span>' +
        '<span class="badge">' + ELIPS.escapeHtml(accessLabel) + '</span>' +
        (item.availableFrom ? '<span class="badge">Tersedia ' + ELIPS.escapeHtml(item.availableFrom) + '</span>' : '') +
        '</div>' +
        '</header>' +
        '<div class="learning-article-body">' +
        (item.description ? '<p style="color: var(--text-secondary); margin-bottom: 1rem;">' + ELIPS.escapeHtml(item.description) + '</p>' : '') +
        body +
        completionNotice +
        '</div>' +
        '<div class="learning-actions">' +
        '<div class="learning-nav">' +
        (flatLessons.length > 0 ? '<button class="btn btn-ghost" onclick="selectLesson(' + flatLessons[0].lesson.id + ', event)"><i class="bi bi-arrow-left"></i> Kembali ke Pelajaran</button>' : '') +
        '</div>' +
        completionButton +
        '</div>' +
        '</article>';
}

function markComplete() {
    if (!activeLessonId) return;
    if (isPreviewMode) {
        ELIPS.toast('Mode pratinjau: progres peserta tidak diubah.');
        return;
    }
    if (!lessonUnlocked(activeLessonId)) {
        const item = classroomLesson(activeLessonId);
        ELIPS.toast(item && item.reason ? item.reason : 'Materi ini masih terkunci.');
        return;
    }

    if (classroom) {
        const result = ELIPS.setMaterialProgress({ classId: activeClassId, lessonId: activeLessonId });
        ELIPS.toast(result.message);
        if (!result.ok) return;
        classroom = result.data;
        buildFlatLessonsFromClassroom();
        const index = flatLessons.findIndex(function (e) { return e.lesson.id === activeLessonId; });
        const next = index >= 0 && index < flatLessons.length - 1 ? flatLessons[index + 1] : null;
        if (next && lessonUnlocked(next.lesson.id)) activeLessonId = next.lesson.id;
        renderAll();
        return;
    }

    ELIPS.markLessonCompleted(activeStudent.id, activeCourse.id, activeLessonId);
    ELIPS.toast('Pelajaran ditandai selesai!');

    const index = flatLessons.findIndex(function (e) { return e.lesson.id === activeLessonId; });
    const next = index < flatLessons.length - 1 ? flatLessons[index + 1] : null;
    if (next && lessonUnlocked(next.lesson.id)) {
        activeLessonId = next.lesson.id;
    }
    renderAll();
}

function markMaterialComplete() {
    if (!activeMaterialId || !classroom) return;
    if (isPreviewMode) {
        ELIPS.toast('Mode pratinjau: progres peserta tidak diubah.');
        return;
    }
    const item = classroomMaterial(activeMaterialId);
    if (item && item.locked) {
        ELIPS.toast(item.reason || 'Materi ini masih terkunci.');
        return;
    }
    const result = ELIPS.setMaterialProgress({ classId: activeClassId, materialId: activeMaterialId });
    ELIPS.toast(result.message);
    if (!result.ok) return;
    classroom = result.data;
    buildFlatLessonsFromClassroom();
    renderAll();
}

function toEmbedUrl(url) {
    if (!url) return '';
    const value = String(url).trim();
    const youtubeMatch = value.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([A-Za-z0-9_-]{6,})/);
    if (youtubeMatch) return 'https://www.youtube.com/embed/' + youtubeMatch[1];
    const vimeoMatch = value.match(/vimeo\.com\/(\d+)/);
    if (vimeoMatch) return 'https://player.vimeo.com/video/' + vimeoMatch[1];
    return '';
}

